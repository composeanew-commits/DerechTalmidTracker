# Derech Talmid Tracker — Standalone Setup Guide

This is a real, installable app — not a Claude link. It works fully offline on every device
once installed, and syncs between devices whenever they have internet.

## How offline actually works here

- Every device keeps its **own complete copy** of all the data, stored locally (IndexedDB).
- The app **reads and writes to that local copy instantly** — attendance, observations,
  everything — with zero dependency on internet, every single time.
- When a device has internet, it quietly pushes its local copy to a shared Supabase database
  and pulls down anything newer from other devices. This is entirely automatic.
- If two devices are offline at the same time and both make changes before either reconnects,
  whichever one reconnects and syncs *last* wins for anything that overlaps. This matches how
  the app has worked from the start — it isn't a new risk, just now relevant over longer
  offline stretches instead of just brief wifi drops.
- **A device needs internet once** — the very first time it opens the app, to download it and
  install it. After that, opening it never requires a connection again.

If you skip the Supabase setup entirely, the app still works great as a **single offline
device** — everything local, nothing shared. Add Supabase later, any time, from Settings.

---

## Part 1 — Get the app onto a device (no internet needed after this)

You need to host these files somewhere reachable by a URL once, so each device can visit that
URL and install the app. After that first visit, the device works offline indefinitely.

**Easiest option — Netlify Drop (no account required for a first test):**
1. Go to https://app.netlify.com/drop in a browser
2. Drag the entire `dist` folder onto the page
3. You'll get a URL like `random-name-123.netlify.app` — that's your app's address
4. (To keep this URL permanently instead of it expiring, create a free Netlify account and
   claim the site — takes one click from the same page.)

**On each device (phone, tablet, computer):**
1. Open that URL in the browser
2. **iPhone/iPad (Safari):** tap the Share icon → "Add to Home Screen"
3. **Android (Chrome):** tap the menu (⋮) → "Install app" or "Add to Home Screen"
4. **Computer (Chrome/Edge):** click the install icon in the address bar, or menu → "Install
   Derech Talmid Tracker"

Once installed, it opens like any other app — no browser bar, works offline, has its own icon.

---

## Part 2 — Connect devices to sync with each other (optional but recommended)

Skip this if you only ever want one device. Do this if multiple Rebbeim need to see the same
data.

1. Go to https://supabase.com and create a free account, then create a new project (pick any
   name/region/password — you won't need to touch the password again)
2. In your new project, go to the **SQL Editor** (left sidebar) → **New query**
3. Open `SUPABASE_SETUP.sql` (included in this folder), paste its contents in, click **Run**
4. Go to **Project Settings → API** (left sidebar, gear icon)
5. Copy the **Project URL** and the **anon public** key
6. On each device, open the app → tap the gear icon (top right) → **Settings**
7. Paste the Project URL and anon key into the matching fields, tap **Save Settings**

That's it — every device with those same two values now syncs to the same shared data.

---

## Part 3 — Photo attendance reading (optional)

This feature calls Claude directly from the app to read a handwritten attendance sheet. It
needs your own Anthropic API key:

1. Go to https://console.anthropic.com, create an account if needed, and create an API key
2. In the app, Settings → paste it into **Anthropic API Key** → Save

**Important:** this key lives in the browser on each device you add it to. Anyone with access
to that device's browser developer tools could see it. Only add it to devices you trust, and
only if you're comfortable with that trade-off. Everything else in the app works without it.

---

## Updating the app later

If you ever want to change the code (new features, fixes), come back to this conversation,
make the changes, and re-run `npm run build`, then re-deploy the new `dist` folder the same
way (drag it onto Netlify again, or push to whatever host you chose). Existing installed apps
on devices will pick up the update automatically the next time they're opened with internet.
