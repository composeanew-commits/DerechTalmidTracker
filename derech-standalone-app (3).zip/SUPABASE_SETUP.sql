-- Run this once in your Supabase project's SQL Editor (Supabase dashboard -> SQL Editor -> New query).
-- This creates the single table the app syncs to. All app data (students, attendance,
-- observations, follow-ups, goals) is stored as one JSON document in one row, matching
-- how the app already works — every device just pushes/pulls this one document.

create table if not exists derech_data (
  id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

-- Row Level Security: on by default in Supabase. This app has no login system, so we allow
-- the anon key (the one you'll paste into the app's Settings) to read and write this table.
-- This means anyone who has your Supabase URL + anon key can read/write this data — treat
-- those two values like a shared password for your staff, not something to post publicly.
alter table derech_data enable row level security;

create policy "Allow anon read" on derech_data
  for select using (true);

create policy "Allow anon write" on derech_data
  for insert with check (true);

create policy "Allow anon update" on derech_data
  for update using (true);
