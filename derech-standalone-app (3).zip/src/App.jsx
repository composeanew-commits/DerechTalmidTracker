import React, { useState, useEffect, useRef, useCallback } from "react";
import Papa from "papaparse";
import {
  Users, ClipboardCheck, MessageSquarePlus, LayoutDashboard, AlertTriangle,
  ChevronLeft, Plus, Search, Phone, Trash2, Upload, Settings, Check, X,
  CheckCircle2, Circle, Clock, BookOpen, Flag, Loader2, Save, RotateCcw,
  Download, Copy, TrendingDown, ChevronDown, ChevronUp, Camera, Pencil, ImageIcon,
  Cloud, CloudOff, Key, FileText, ShieldAlert,
} from "lucide-react";
import { getConfig, setConfig, loadLocal, saveLocal, pullRemote, pushRemote, isConfigured } from "./storage.js";

/* ------------------------------------------------------------------ */
/*  Design tokens                                                      */
/* ------------------------------------------------------------------ */
const T = {
  bg: "#F3F1FA",
  surface: "#FFFFFF",
  surfaceAlt: "#ECE9F7",
  ink: "#342B71",
  inkSoft: "#5D5590",
  inkFaint: "#9791BF",
  brass: "#4A3F9E",
  brassDark: "#2E2568",
  sage: "#4B7A5E",
  sageBg: "#E2EDE4",
  brick: "#A24E3C",
  brickBg: "#F4E1DA",
  border: "#DAD5EC",
  borderSoft: "#E8E4F5",
};

const FONT_DISPLAY = "'Avenir Next', 'Century Gothic', 'Futura', -apple-system, sans-serif";
const FONT_BODY = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";

const SEDARIM = ["First Morning", "Second Morning", "First Afternoon", "Second Afternoon", "Night Seder"];
const AREAS = ["Learning", "Davening", "Middos", "Social", "Motivation", "Personal", "Family", "General", "Other"];
const ATTENTION_CATEGORIES = ["Attendance", "Learning", "Davening", "Motivation", "Social", "Personal", "Other"];
const SHANA_OPTIONS = ["Alef", "Bet", "Gimel"];
const THERAPY_STATUS_OPTIONS = ["Not discussed", "In therapy", "Wants therapy", "Doesn't need it", "Not interested"];

const LOGO_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAAKMWlDQ1BJQ0MgUHJvZmlsZQAAeJydlndUU9kWh8+9N71QkhCKlNBraFICSA29SJEuKjEJEErAkAAiNkRUcERRkaYIMijggKNDkbEiioUBUbHrBBlE1HFwFBuWSWStGd+8ee/Nm98f935rn73P3Wfvfda6AJD8gwXCTFgJgAyhWBTh58WIjYtnYAcBDPAAA2wA4HCzs0IW+EYCmQJ82IxsmRP4F726DiD5+yrTP4zBAP+flLlZIjEAUJiM5/L42VwZF8k4PVecJbdPyZi2NE3OMErOIlmCMlaTc/IsW3z2mWUPOfMyhDwZy3PO4mXw5Nwn4405Er6MkWAZF+cI+LkyviZjg3RJhkDGb+SxGXxONgAoktwu5nNTZGwtY5IoMoIt43kA4EjJX/DSL1jMzxPLD8XOzFouEiSniBkmXFOGjZMTi+HPz03ni8XMMA43jSPiMdiZGVkc4XIAZs/8WRR5bRmyIjvYODk4MG0tbb4o1H9d/JuS93aWXoR/7hlEH/jD9ld+mQ0AsKZltdn6h21pFQBd6wFQu/2HzWAvAIqyvnUOfXEeunxeUsTiLGcrq9zcXEsBn2spL+jv+p8Of0NffM9Svt3v5WF485M4knQxQ143bmZ6pkTEyM7icPkM5p+H+B8H/nUeFhH8JL6IL5RFRMumTCBMlrVbyBOIBZlChkD4n5r4D8P+pNm5lona+BHQllgCpSEaQH4eACgqESAJe2Qr0O99C8ZHA/nNi9GZmJ37z4L+fVe4TP7IFiR/jmNHRDK4ElHO7Jr8WgI0IABFQAPqQBvoAxPABLbAEbgAD+ADAkEoiARxYDHgghSQAUQgFxSAtaAYlIKtYCeoBnWgETSDNnAYdIFj4DQ4By6By2AE3AFSMA6egCnwCsxAEISFyBAVUod0IEPIHLKFWJAb5AMFQxFQHJQIJUNCSAIVQOugUqgcqobqoWboW+godBq6AA1Dt6BRaBL6FXoHIzAJpsFasBFsBbNgTzgIjoQXwcnwMjgfLoK3wJVwA3wQ7oRPw5fgEVgKP4GnEYAQETqiizARFsJGQpF4JAkRIauQEqQCaUDakB6kH7mKSJGnyFsUBkVFMVBMlAvKHxWF4qKWoVahNqOqUQdQnag+1FXUKGoK9RFNRmuizdHO6AB0LDoZnYsuRlegm9Ad6LPoEfQ4+hUGg6FjjDGOGH9MHCYVswKzGbMb0445hRnGjGGmsVisOtYc64oNxXKwYmwxtgp7EHsSewU7jn2DI+J0cLY4X1w8TogrxFXgWnAncFdwE7gZvBLeEO+MD8Xz8MvxZfhGfA9+CD+OnyEoE4wJroRIQiphLaGS0EY4S7hLeEEkEvWITsRwooC4hlhJPEQ8TxwlviVRSGYkNimBJCFtIe0nnSLdIr0gk8lGZA9yPFlM3kJuJp8h3ye/UaAqWCoEKPAUVivUKHQqXFF4pohXNFT0VFysmK9YoXhEcUjxqRJeyUiJrcRRWqVUo3RU6YbStDJV2UY5VDlDebNyi/IF5UcULMWI4kPhUYoo+yhnKGNUhKpPZVO51HXURupZ6jgNQzOmBdBSaaW0b2iDtCkVioqdSrRKnkqNynEVKR2hG9ED6On0Mvph+nX6O1UtVU9Vvuom1TbVK6qv1eaoeajx1UrU2tVG1N6pM9R91NPUt6l3qd/TQGmYaYRr5Grs0Tir8XQObY7LHO6ckjmH59zWhDXNNCM0V2ju0xzQnNbS1vLTytKq0jqj9VSbru2hnaq9Q/uE9qQOVcdNR6CzQ+ekzmOGCsOTkc6oZPQxpnQ1df11Jbr1uoO6M3rGelF6hXrtevf0Cfos/ST9Hfq9+lMGOgYhBgUGrQa3DfGGLMMUw12G/YavjYyNYow2GHUZPTJWMw4wzjduNb5rQjZxN1lm0mByzRRjyjJNM91tetkMNrM3SzGrMRsyh80dzAXmu82HLdAWThZCiwaLG0wS05OZw2xljlrSLYMtCy27LJ9ZGVjFW22z6rf6aG1vnW7daH3HhmITaFNo02Pzq62ZLde2xvbaXPJc37mr53bPfW5nbse322N3055qH2K/wb7X/oODo4PIoc1h0tHAMdGx1vEGi8YKY21mnXdCO3k5rXY65vTW2cFZ7HzY+RcXpkuaS4vLo3nG8/jzGueNueq5clzrXaVuDLdEt71uUnddd457g/sDD30PnkeTx4SnqWeq50HPZ17WXiKvDq/XbGf2SvYpb8Tbz7vEe9CH4hPlU+1z31fPN9m31XfKz95vhd8pf7R/kP82/xsBWgHcgOaAqUDHwJWBfUGkoAVB1UEPgs2CRcE9IXBIYMj2kLvzDecL53eFgtCA0O2h98KMw5aFfR+OCQ8Lrwl/GGETURDRv4C6YMmClgWvIr0iyyLvRJlESaJ6oxWjE6Kbo1/HeMeUx0hjrWJXxl6K04gTxHXHY+Oj45vipxf6LNy5cDzBPqE44foi40V5iy4s1licvvj4EsUlnCVHEtGJMYktie85oZwGzvTSgKW1S6e4bO4u7hOeB28Hb5Lvyi/nTyS5JpUnPUp2Td6ePJninlKR8lTAFlQLnqf6p9alvk4LTduf9ik9Jr09A5eRmHFUSBGmCfsytTPzMoezzLOKs6TLnJftXDYlChI1ZUPZi7K7xTTZz9SAxESyXjKa45ZTk/MmNzr3SJ5ynjBvYLnZ8k3LJ/J9879egVrBXdFboFuwtmB0pefK+lXQqqWrelfrry5aPb7Gb82BtYS1aWt/KLQuLC98uS5mXU+RVtGaorH1futbixWKRcU3NrhsqNuI2ijYOLhp7qaqTR9LeCUXS61LK0rfb+ZuvviVzVeVX33akrRlsMyhbM9WzFbh1uvb3LcdKFcuzy8f2x6yvXMHY0fJjpc7l+y8UGFXUbeLsEuyS1oZXNldZVC1tep9dUr1SI1XTXutZu2m2te7ebuv7PHY01anVVda926vYO/Ner/6zgajhop9mH05+x42Rjf2f836urlJo6m06cN+4X7pgYgDfc2Ozc0tmi1lrXCrpHXyYMLBy994f9Pdxmyrb6e3lx4ChySHHn+b+O31w0GHe4+wjrR9Z/hdbQe1o6QT6lzeOdWV0iXtjusePhp4tLfHpafje8vv9x/TPVZzXOV42QnCiaITn07mn5w+lXXq6enk02O9S3rvnIk9c60vvG/wbNDZ8+d8z53p9+w/ed71/LELzheOXmRd7LrkcKlzwH6g4wf7HzoGHQY7hxyHui87Xe4Znjd84or7ldNXva+euxZw7dLI/JHh61HXb95IuCG9ybv56Fb6ree3c27P3FlzF3235J7SvYr7mvcbfjT9sV3qID0+6j068GDBgztj3LEnP2X/9H686CH5YcWEzkTzI9tHxyZ9Jy8/Xvh4/EnWk5mnxT8r/1z7zOTZd794/DIwFTs1/lz0/NOvm1+ov9j/0u5l73TY9P1XGa9mXpe8UX9z4C3rbf+7mHcTM7nvse8rP5h+6PkY9PHup4xPn34D94Tz+6TMXDkAAC9CSURBVHja7X17nBzVdeZ3zr1V3T0zkpAsJCSMeJpHj3iIEWBjO6PgxxLHceKNm3XirO1kHbK/DQYEwXZie5tJNnEcDAKz8SY4r02c7JrZbJyNTZzF8TLGr4AmBNA0j8iAbJCIJEtImkd31b3n7B+3qrt6NBJyjATY9elXqprurqp76p773XPPOfcWUKJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaLECwX6IZFJy6ouFfAFKW8TTWo1WrRzZ71b9hUrhrVen9KxsTE9hLJRs9mkVmuYdu6cKpzX0vHxOwUgPXbPu0nNJtBqtQhooFiew2HFimEFxlGv13Vs7EbNqk5LBTzaCtds0j33gFesGNbx8Sv8kZw0Otq0Z02vpseGtuvExJg7knMajTvNzp1TNDEBAQ6pyEeIJjfQop2joZEERR/3L/TDaTabfM894CNshKUCHmmZGo07GQAWUDh659s+vooq/mQVPZ1UT1ai1UR0gqosBTCkikFVVKDCIioq6KjqjBedVq97vcizIvSMT2WbiH6rw9h2772/tWMhJV4x0dJxjMvzV2iTG43ArodT+EsvvWFRReNlNtalkTFLyeA4NrTYGB4wxFU2ZEBKDICZPBF3lGiWiQ8Q/D4S3ZtY3Svi9tbreG5sbEwWbkwNs3NnnTZsgLzUFfIlo4BNNPmeUXCxAi+//LbKYvvceWrtpQx9NTOdq4RTrIkGrY3ATF0TTzXfBCL5MaCiEAVUABFAROG9wjmPJEmQJum09/KU93hQnHwjVfn64NJFDxfLMTratBMTN/r5XXX4HAL0K8L552880Tp+lWXU2fDZNsIZxvIrjaEVbPi42NpKFFmYyMIYA8MMNgTmsBHlG0CEglweIt4psF8FuxW6XVWfgPCjIvqIeDy6dNUrtt1xxy+l89k9NOjGsTQ3Xk4KqJQ/mLe+tTkQpfyjZPFTxPSjxpjTK3EVxAAgUHhAVYkhBFIQAdDwPwCVcKGu8olARVVE4bxAVdV7gUuFvBcWIRJPEE9wTtHpzMGLPsbgu8noX9WWDn2loIy0EJusH77uJACXAtig0EsI9CrDZiiKY1jLMAbgbDMGMIbABsLMag0r5QpIBQXkoHwAgUhJlYgIhPAtKPAkAIJq3qDaTkWfEtEHveJrcPrVOex+6ItfvL1TbOhjWJg5f6gZ8M2jzbOjSN9jDP+7OI5PtdZC4UAkysw+qxhmA8qAUB8AgTKtCMwHRZcRRXqb99Ldexf2znl1TtSnIqkTeKdWhMFkIeoh6qeg9Ceks5+5v/WpZ/NnNnryeyrTg8t+mYjeAsLFhuMhAkHUQ8WBjIq1RowlWMNkIyZrmYxhmHxvOLCeITBnxwRQroRB3+ZVkqqqQjSTUlQDwwuJwAAMKEMESJI20tR/S718OfX4a2+Tr37pSx/fV2zwP8wKSIDi8suvjt304F9GlfjN1Uo1AnkQRIxlYWY2ltjkXRMTmLi3L1SQHtQVK0QlY8GeAnofWNE7gfPZvrilApd68V4FUGaOOLaDSNzMflH/U5NTm+4ZGbnSDg2t0pld+/4wjhe9O0mnoRk1E4GJiKxlshEHBrRhH9gw/B1YkEP3myshFWSkwHKUK2AmZGD30CV3Zew1NPVeVb2oF1XvxUCZVA2SJIF47Oh02r/75a//9m82m00+lA15LMEv1o1HR5sGIE1mBn6mVlv840RivLQdgvKxMWStJTYm654Mw7CBMQbWWBhjYaztHtvuFoXvjIFhE5jFhAoOrJPZWnnlF5jIZBsbznpDw0wGSXrgbwXyjtTwfQAwNLRKJybGPDFud67jFeqJYIjIAsTMREWbLmxFtgt/G87LVSxTT8Z8M8bC8Hw5s7/ZwmTXMkxkDTEbNsaQNYZIIeKl7VSdB+kqZv711198/anBldPkF1sB7YvFfhMTkHq9GTOSD4kmwsRqmK0x8yos24IyZQpF3GMHOqiDAqtAVEAkIPIgIQA+40iCggODGIJRgnJQThUFGQJ5iLUxOy/7vaYbN0/d8kfFe0xP7yAA6hU/Exk2cHB5X0KEeYpXVHzul8tkSsjUk40NmMLvgowHd1Q5A5IKlKgnH0lmJwduUQWMEYYyqwGcc2kcVyPx/gaA/lOjcSePj/8QMmBgvzFZuazz7ypx7SxVp8aQ6as40698va3ABLZ/32W+nDG4wILdiueDFIQLXTwRJIpiBnSbR/L6zVtu+aMmmtxAw+QujsnJO9ILz7nq9Zai93vfESIy3ZZF1LPhcrOhsO/b8i43a1xdGU1hfxDrmT4ZmQ04Z3viPlkOPmYrmigZ8543vvaDa8bHr5AXmwXNi3HTbds2YGTkLFuLan9urVnOrLCWKe8Ou1tWOabvwZtC92rAeSXkFZAZ77kbIwxRigE57R13barsWEUIhlRkt5P2hs0PffKRkZEro/+x4xbfQkuBJrdan5J151x/smH7f0FYDIgiG6MDAJv5tl7vuF8+6v3NRXkymQ4hIzF3ByjdHkB7JKmFQXpXtp6MpCrecLWSpIl96umv/W2j8cvcao3rDw0Djo42LTAmi2vL3hHHtXNEnTAzU84IfQzChW7XFJjCwpgIxobNmjiz/fKtoJSFbi2vPC6yU9f1EdjLGEtK8t5/+KdP/vPIyJXR5OQdaXHAdvkZ768wybhhu1LE+aLyESGMYrtbzj69rjn/LmfAbndbZMGuLWiDjAVZjYkC8xnbz+7EBfMk3LPo1ukxPBmRjhKZXxi9+AOvfLFZ8JjfeGICMjratCT6a4BoeDDo77K6Tth5D5dDxbCx4EzZ+hTPRmATtm73xHkFc7fCKasc6ro8ABB8HNVYNPmbr/zDTXeNjjZtQfm6ZsPumK+LotpF3nfSYteb62jPiUyZQs53LBd9fVkjI9MnI3NuTuRyFQdXtqeEBaXttx0zhswVnlFUfAKpj6PqoBKuA6CNxjD9UChgzn7amfu3UVRbK5JKNnrsZ428orKK67XuIgOaXmXYCMbGMJxVUl93Fox5ph47hO6rp3zZPQmkYDafCn6y+YOmMT862rQKeq/4VEAHmy80n/2I5h332B2EnslAxQHK/G7YdhuZNXGP4Y3tds3dbpl6svbLVuiuqceCTPy+S9fdsPrFZEE+1uzXaDQMqf6aQrT7YFCotKwm+yuNC5VkeizBWRdsox5DHGQT8kGV0LsX5RaiGrbsfHKAvUwCpCH01j/4nJ7eQURUDabjwY7cjEkzJuzJhKJiZp15TxmK5eOC2dEzNThvZBkDLmT3HiQnFmoI3c8IKt7ayiK2ei0AHR3FD7YC5uy3/clTf9La2vnep2H0WKi0LotkQ4e+f30VZgqjP9tlPjYWxCZs81w11F8D6N43RFI0MCy+u2hPvG8BH702Gneayck7Uih+z5qKCfEI+IO6YHS79K6LqKt46DWy3tZTQi6yWCYHG1OwbaOe8nVt2nlyFp4VupEiFO6WfcVkvCQK0JWXrL165cTEmH8xWJCPJfsBTYbKR6DS18fNDzYVagu9J1gIvVGx4rh70vwutkBJvYe/UBiIuqPH6nMnTkcLlT9k5jR5c2vTx1I3s8maijUcGVX4EAWBHnSD+bLkPkvqsXzXf1hsdtlvA7uZbtSnp5iZ0hWVrcB2RVmpUAyaXyARH5naEjbxNS8WC/KxZL+LL5j5CWMq65wkC9pQCyQpfL9JDkd6NRbxSsQr2NVOQZaHePDPxgRQ2jy16Tqnnbeqyn3WxMaa2ABEquq6yvhCxUjp+WOn9K+NshKM8x1Vwn+84IL3H/9isCAfO/ZTgshHQrYA9WnFfN8Vir6rboKBQuelXan4EPxHL11JRbpx0vycPHqAgl8s9wEWCuKtqbJ6/9MA9POf33GIBkLaQMNMbrn1C/dv+cSrHfxPibr/Q8BsZKvW2qCMUHUKlb6bzDtWLboltU/wPjkLJ4pK4UTtxoaLCRjhc+27pS7cDEnVe8uVpTa1738xWPCoO6IbjTtNq3WVXDh84K2RiX9FkYphMnlEopsRkrskcrdMFrWgwii2ONKjXrJceNwhVy5sWjgWCSlZOn+PLIAfEha8KHnvIaLDp6x47R9/bfNt041Gw7RarYPYrIWWNtAwLbRkx86vP7Z95zf+5+oTLvmfBNpKpBETTqxUB2JjiAD1WYSCuOhmKsqXy008Tz4uNNWQeNAvo/SOs0bXlU8kS8YARLWbmiaiUK8Qr/AhgYGyLKG1J75i9A+/Pvmbs8ELMPaDoYCtVp2ACaw+/pI/ZWNeCVI1hrg/QM/zQlOZawJFQzt8j774b2j5opKnTmUV5A5SSJ8pYmDJ/jStsIGccwKKFjnv6yefbsbvuusuPzratNu2TchCSpiH5lqtBm3f+fE9T//L1+779vav/dnJJ73+s2DZzqDVcVxdaQyTqnhm5q5smZ+zu2U2LKiYitUN/mbKJH1y6ULKmMuZZwKFVK2unLnsXgTic7m9N1wZEu3MbN/1zYnRUSwo81FKiTq67Dc+foVff841P2Zs9S4viY8iNjZmRNbARowoMiFVKQphKWtNN13JsOmP8RZ8Y91RInEhVUm7FRPYzMGLh/e9vfMO4gXOK7zzcK4/JStJnIfGptNpf3lutv3zk61PfhtQauAKHsfh5nU0eXQUXMyQbjSa8ew+bUTW/Gq1WhsWScRYImsN5fLlfsu+DJ6CO6krY1cXpceE3sGLg/f9MnrvIOLhfZ7zKAU5g8xpSDsLx4moKkFVdne4ctbDD3/subyHflkzYKNVpwlM6KoVr/nvzPYkVa/MOftR12ufdz99Kencc2VQd0Tc32K6NmG3xRe7Xg8/rxsObCEhNd8X8gRFuqn64pWTNPGk0eki9K5VK17z3e07/80DGeNRMCkWSiGZ0MAaExqUcYO5666x9J+/NfHwca9Y98eDtZitiX6EACXSLKsW2WiXelGUnPl0nozaMx967Oe68mnOgt19xnp+IbaXXNb8MxIRH9naIpb2/u27fuzeY8WCdLTZb2T42jdbjv/OSSIEYmMINsrYL2M+m7GhzQP4thew7wbq+4Lz/SlZeY1pxhDFisqV0PvsOEtKzZNRe+znC6ygSBPnxZMhiiCa3iuQ357csumuIuPh+VPbaXS0afKU/ne87dffHUXxnxAHM6THgv0hNVOI4BAzCLxgd5wrW2B732XDcKxBPt9Lvu1Pus3YMA2fqaoQWRLxO1GLz5qc/O39x2Lqpzna7Ld6xWv+mMmeLCpC2ai7n+nmxYID4ymBlAhCQEhy69vyKUdh2ptCRMWrqKiIiPdeRLwEePXitWcDKvUypHMG7KXrS26g++CaEfHCbE9hMu9aveLVb1694lJ9xcoLtu3c+Ym5I2nAGYtQo9GM/9df3fiP55w5OliJq68TcZ6D8deNxkCDzCHtHgLNZrOoiorXIKNXKe6DjNk/EVEJJ/h++1a8QDwQ9sUs8bAPbiTxka0t1rSzZ/uuy792KPv3Jc+AOftdWL/+MmvM33ufCPU8xl2bL9urtSw2YjWGyVrmKLIU2Qg2ihBFvRSsbgRg/nwJ6obUul2WqEAym8/5FN45OOeQOqfiRJxXdU7IeyHvhJwTytnApcFG6rpuoEIAmGMmMET906LJv5+cum2i0Wjwkcz5bTaDf23rQ7XVjvyjxnCFGdmAjI01WUjRRrCcx3p7siqKrpZ56fiaMXvG9MHOc0jTILNLvffeq3MKl3p2ToO8maxBAQEgsKCqfzZ29qyvP/Y700ebBY9KRnR9fEqDk9F/lGDnGbOqXkTIQ5lhoZaYK1kFhMxen/ppUdnuJPlOJ6WnGfoMMT2rInuIdB+pzjBxR5gce1aNxBAoYkQ1EBYR81KIHq+kJ6joiao4UURXey8rmaIKW2OIBFAH8SlEEviMML0X8iKkqlyI1IQ5eZKIKpJKvOiVndS9DsA9xRUaDodsNQNtNJrPoWO0Vhm0xAAzIOqQunRWxO9yPt1hmHcQ+FkQ72TCdwnYB8W0QNuq3omoEpQFGqvzg550kSqWwuvxXnWV97rai64S709QwXHGVEwovwNRCtUEIurFi4oIF0JOLOJcZGurOjr3PoA2hamnRza5/yXBgI1Gw4yPj/v1azeOMkX3BPYLpkuwty0bE8FaA+IUxuhTxpoH2ND9BH6YjXliURV7Fq9anKwYXBXFA/FgxNXFkRlYgoiXQHhQ4avEFKkQASLMtkNAG4wDpLzPRNW9Ebu9p629eO9b3kLdKYkjI1dGr1y+6kRj+SyFXuBTHUmdnOecPw0aRd4DaeKQJB1471QVPkTuw/xHhQqTIVXsA/S8zVO3PA006QhsQTSbTW6NtWj2zeeurVbov0eWHooi+49RzT68fOXixz7+8V98hmjhUefv//7m6Lmt7eqiZYutiWIDAEMDNT8XD7j/cMHyNq2n9FD3feOlN6yOBuOz4WmdF13vUjnfpf5V0Mg6p3DOQSSFqrosTQFEhkX8M3PonNNq/e7M0WTBF1wB89lWI/WNdxsTb/C+A2Miy2ThJYWqbFXoVyybe421j9UW2fZgzbyiWo3OjCp2bRzzcGSj06yJVy8aWsK12mJUq0OI4xoiW+lGNXoRgb6E4G60IElmMTt7AHPt/Unqkl0u6Tydeve4c0nLO/9Q0pFHh5Y/+Z077rgjbYw2h/am6dlJkr6242SDT/ViZruayULVw0sKqKYgMsyWveu8ffKR2z6XN7Z/7bNaOfgfVyxdbk5fclz17EWLojMHBuLTagPRmkrVrozj+Lg4ri6qVQZtrbYItdoQKpUhGBPlvSVENZgZLoGIbwt0n4jflXZmn07T9pOdtP2YeLelEtlHbvrd923v9lD1/zS0NB56TerTy0XpDVCcZ02FVCWvo4611Ypz7asnW7fefjRZkI4G+1187sZXE+JvBGVwUNWHiejLEDxAhmdVZQ0R1sVVPq9ai15Zq9o4rtjZuGJ2x7F5phJFz1hbedZGlV1xpfbdmON9UWXgQCWqzIh3HYqqCdBx3rO3JlLnU7KGSJPUsqlE3mjFJ+3B1HUWtZO5ZZIky5O0vTJxyco0TU5IUrc86fhap+PSzpzfNddOHunM+MkkSSd9NfrWwB4Rt4xPh5c3QvltIH2tNdXYS+qd77z3gUc++Znczj3CmDQ1cAU/OXzizzJFl4u604mwWoEBKHylauZqA/G+gYFob6Vm99Zqdl8cVw7EUTwbx9V2HNWSSlTzUXVAiQyRqgEoJpWKEg0ANETQxSBa6sUtS5K5pUkytzRN5hZ7EXSSOczMzrU77fSpzpzfPDubfqW9f27iqw/d8jgAXLL26pUK++Oi1AB01Ji4RiA4P7dtVpec2WqNpS9QcP7oKmC+WM70rv3fiEzlzNQndxHRvQD2EGGFKq0BZAiq+4j1yepA5XFr7TY72H727rtvnjnWmRhvfWtzudvvT5qdTU5tJ3KaeL8KoJiJd4vSowb0UNt2dlST+Hi19HYnnQf/ceq2v/seGYEA6CVrr17pxLzXULRbJNnmWZ+pKP/LN1uLn8NRWKmg2Wzynj1nDCX7dy8Tcse355KT2nP+9HY7PX121q2Zm3FLOomfZfCjxPIV9Xzv/a1PPDtS/+AaovTtqnpFHA1emrrpD2+euvW3jhYL0gt8LR0Z+eASmuv8XJrS56yfmabB2gkgG3nDex544Hd2HM673mw2udUapvrOKcKG/u+GW8M63u1CGnro0N84AUADwFR9ipBdaMeOxwkAHntsuz7falUjZ163PKqYNV6w2lM6QMLbJ1u3fDXjeQM8f7fbQMPsHK3TihUhZDc+XtdDK1pvcaPp6R00MjJy0C9WrTrzsOwzPLxBx8fHka2QdUQKff751xwXp9EpamgNRJYIdC8DD26euuU7AHDxuTe8Xrz7Ua3NfGJy8o65lzwDLtT19Ctck0dGdpi5uVUEALXaDh0aWqVAvv5dwJGumVdEXtEYB8ZRz671wq2jV68341YL7gjZio5CZWXT327MGliL0MifV/9IPJu3DGAEp81tpwNr9hBwBubm9oTn/swenTtxmV+I0c477/rB2dnEvWvrsjRfQ6aBhjmyVcJeEgqoFB7SS2cBnPlsU6/D1mo7bGV6iTkQT1uigShKvCHDVsExSCKQRgqOI7K1JHXfeeCRm7cd4ZoqBEDXnX3Na+K4ssqnnTmCSYTQATQhpZSJOirqKKYUmqTqK06cOCyK0jR1bum+3R6nnOJCft4P9uquR8kR3TBPPLGUo38ZtDxo7YF42sadmgFLRIYtp2SVNVK4mJisgGNVrRhwrKBYjVYYEquiouAKQWMAMVRqAMXKFJOipqoVAiogqqpqFaCYoFUFYoBiIlQUqAAaEVABKAY00rCPoRQRkemtwZJlo3T3AIWlObZrNa5PTlYPZF69QzSuhgHulHVnXbXK2OoTlWioooWMvG5+Ywh2dPMYw3EIfEDhAE0USABKAE2I0Mn/JmhbQSkUnXCMDhE6UMwpUZsQjgEk4TttKzgBNGHVtgAdgiZK1AY0IZhEmDqqaQqllCGJSOwgnGqtnQ75QSeJd52hAT85OTb7UlVAAoAzznh/fFxsv0hs16o4q9AKgIiIbC/tiHuRi26+WzGVvJC6rsXq6yViqhYrUbrxX1V1BEqU4ABNCdQBNAWQKqhNQAJFB9COAh0QOqQUKjGrFAI6ofI0ATBD0JPiaPFVSTL9B5tbm34xH2jNY6cs5hvWEFw/vPGzkR28Ik0P/JqCtykwyNBYQVUCYiWtklJVoTGBqkoaPldUwt+oELSqmv0eqIBQgWpEeeMBIoAiEKLis+1NU6BCnPzQFoEWMmP7n2svAQKqKbH1Iuk/DB2/5I0vJDO/oJGQOF6moH07ABkAdDZThjaARFQ6JL7da5nUVmhCQEdV20FZaFZV9hLQ6XZb6lOCSciIEQdBRClBEoBS9eIYcSJOnauJS9PUHT9zvNs12JLhFvw4XphlcdcPbzypUjnufSNrN+4cGxv7cBaT7qvHiYkx10DLPLX2+psr0ZIr5jp7PjPZuu1jR8OEGBnZYYZ2rzK7BnfZyEbWzpFlq9ZLh6wVcWpjRRqDokjgYqOokNjFYqTKoNCzqFYAqoJRgYYGASAGaVVB1ayHqBKhAtIIwCARTa2YaOlLvgv+fnDR+R8YptSrSMqII6gKGQGfPPX0lu9ToQ5hxB96ofDp6R102mlvlGceun8gsf5z1fi4y9rJc98A6GOpdfc++OBtzwHAq+sblzniDQR8pBIvWddO935+8MDiBk6Bm57eQflA62gPpEZGPriEnb5SvPMhRO4VCaA2cpNTn/jWD4kN2JvUciSVnI3KzNyJy/zMnpkNluO7RdJC0RTMEVI3+29Om3rm71GHGW/V543ebtTDiPN9ttgw8KjXG/EArRlj4g9ZO4Ak2Z+CdFtYngqnxNFik7oZr5Df2LzlO/8lc9W80KNhWki8ev3GqNWCWz984LrIDtyUutnubEEigvjUK+S004Zf98wTT+zloaHtR1ymfHV+ZD6wF6pXOSpd8HwDfbz/v8P5zPSLW2/3F517fSKSiIgT9CZMCaAMUDqOcd8YbgCt+YOAozl/gRRQarUoAfCrF595/R2JTr8DRJcp9DQQlEBfdOnMlxTyl7kP7Si5YnQhnTz++GaWhb3RqXoNE6K8Db8nAtGcOO9C5EZfUutE25cgKXP/XlFcAOhFKlOWDd3g8fGbnwRwU7Yt6AHInNz64hVWu2uDISwi/ZJ9HYdFiSNmn6BYYe5H9goHX4x6TExAxsfHfPmoXh4KSCGV6UYFrjgKjvAX9G1CVPC4SJh41MM4xj0mDvn7F6IML/T1Ctd8cd+4dMy7tkajYbKBShYbDfbI6GjTakg8/lcNfMLqC3l32b2uNtAw2Xsy6HDnFrd8NdReefPFiChbV3nB1QOo0bjTZOcWfh9qOZTve1l1oCsTzb9eo9Ewhe++J6UbGblj3jWhIRZ9p/kBZ8AwmsyTAEbrzaEZOrA0MtSpP3Tz7vEJ+PXD16Xf6yMNNteYz1npded+aGmCmUFSSg/I0r3jrbEE3YWQF5pINHYQoxXLPD5OHgAuqv/KCRVjO199eGzvwiP/McnTs0ZGfj9K08eXRok3FY2mv/7YTQfyuOvz5xD2Qpl5uS4964ZFPuoMiPPulHN3Plc8v4GG2XkEz8k4MQB0cjK8xObiM5qL2wPT1aVuaHaiNTZdWCuajiUjHiPjtFfx64evfyeB3q2Q8xWylEAJgbcp5DOAPkpk/1rVoRAOEeaIvbjLJqc2/b9CBXb9NBfXr68r03tV9TJATlbVQRClDNqtoAcB3Ll56ubP5q09lCXs1w9ff5Fl+7rUJR4AjI2NuvSh+x9Z9P+AMVlf3/jzZOy1Ku5UgNpE5mHVzoc2T31ycxNNaqFFwRZsmPXDaxoAroDqeSBdDsAoME3gJ5no7712/mRy6vZvHXpGXd9zuoiBdyrp60V0DUgHCJwSsAuEhxV0V5zy//r6YzcdyFOl1g9vvNaa6qbUzbmwYj+UiEhE5lykq2dmZO64SuX9RHi7ipwO0iqAGSLzOMT/xf2tTZ8+1kpoj5Xynf+qXzoxriz6U+bosjybF8ogQo3InMcU/Y73nX2iTun5R725/aLr69f9hjLdYDiqhORXhNfWEGoALzZkTwPR2y9ae8NVcP4X7n907PG+SeQiP2HjwY9qcJrBcIyO7zwNjJ20vn7tlVE08PveJ9nSV1hkTfWyJPEnArj/z8/YE2/dOt4ZOfvaC9na/8ZsLw6RLddd64VAQ0TmBCbzGhVcO1K/rjnZGrslyzDx85/TBWe8//ioEt8ConcxRyTqwZwPqgkEXkZsziLQO1KbfvTC+rUf3bXrcH4uAhFmbMpnHlcxvxvZynovKcBd+28JEa82UWXD+vq1PzaLZ97ZaNXdWHBtHXUl5KOvfCFSEMVDXzIcXebcnHM+8apes7f+qEgizrU9ES15PuXbuXMnNRoNBm6k9cMbPxtFtY+o+jh1c04kDfMwVVMRcapOnG975+Ycs3mtWppYV994BjAmu3YF2Ykwk7pZ53yn7VzbdZL9johOHBne+G4QftP5tnhJXXjTnGqaHpiNnN4PAFu33t4ZGb5mA9togslc7FzbOd/xok5EvFPRVFS8SCKpm3OqMhRHtZtHzrn2t8Yx7nu2ZlC+dedcf3JUie81pvJzqk6DTImoes2elIqm4lzbOz+XGBOdSsDHFi/eb4DwBrODXDKqAKhKpF8wHK1P0hnnu9cUVfXqJfWJm0miaOjtNTrphjGMSViS+GU+CGk0WgSMSQr5b9ZUzk79XBISE2B6M7E0Ix9iVX3eFrdr1wYeHx/36+vPfSyyg1ekbibJzrcAYNgYYyuRNRULEIdsF7LetVPD0QmG9DONRsPUajsUAITIZuda6h0TQT8N0HJVYSKyCgiHW3z7pAuefhYARupXryGyf0nQIec7riAbW1OxxlYiJmNC8cgComk6l9qo+qvrz7nmx8Yx7vPB08jIlQOG9K/ZRGc5N5tmZbe5D1SDxvhschepwmSpGh/95jc3zWXPQBf2XdMQkVnupCNEZHvrpXaX0TQEWOfnBJCrzjvv+sHMZqWXrQI2kM2OG77uUmPiK1I350MmR/HRqBBZZo4YIFI8vwK2WmPpRfVrLiCObkjdjAMoyhWZOWYv/gnvkj91Pvm7LCskXJMocq7tjKle8sSW1T9RXID8EI8mRsgLkdCRsWW2pKCH8kEAEX/CcrzMS9q1ufJMH+87d3vf/h+qfjtTlDU0IoWwqqgSjQFKIXl0TNAe+KCNaud7105BFPU/I0PWVm1ka9bamiUyzGzJuc5jqM3+Rc8DcOgASkj1oryxEzK5igEAVU+G7Amx1/OzOuSXrQLmL2tWyPuYrGIB5TIcs4j7jhe3BaqzliuM51dCFdD1hqOsewGpwjPHJOLuRS2+cHPrlvdMtjZdLqofyX7n+2qD6OeOYNSuClXDMWemwlOq6gnaAoB1a68+D+Cfdr4tRGzzcwisCrxzc+vWN2+euvVnAXq1qH86008JC4SnYOb1Fwxfd97k5B3pRWd/6BUArvK+LciYPFcbwzGr6i7n2n/kfPs3vGv/gag8HtkaE+lvTk7ekeKp57flFaphIU1AVadDo58vMTyxVUBOL9bhy1EBaWJizGUt87UiLqy2VtAhJguR9AOozZ49OfX0BSaSYS/pXzNH0INaZ8++ed25H1pKwOVeEuSvSSBSAlRJ/dWTkx/fl58zObXoY06S/czGhBEhWMUTgS4YPfk91Z7bY0H106yBfMWB1qWW1/o0vcCC/hwArPBPWlNh1VBWVfXGVFnF/e3mqVs+m19n89Qt31HIHxmOSRW933JMRvQ1YSjYfoPlyjIR3/MMq4rhiET8Zub0wsnWrf9h89Sm/7y5tekXh6YXn58m0+9KjPnfAGh6+Q7/fG3Wmip7Sf+KgQvU65le0k8bjrOXLM4bsoAWvcz9gE0CxvS57ftX2ggnCXzXraIKb03FON/+0mTrtpuCE3rUTkyMP7Vu7TUfZ9ifpAVGX6xBged8Msxsl6s6LSy6zN6nnog/PFK/tp0Nk0X1OUNKppfWShR0QJdP15YuBbBj4TipCrMlEfe0zk2/7Z+euCNX6i0Fy+rVQfeouzqIiAOAk0aGN/4hZeNMKISA4dBgimvxEMBYg2CIXkSW+95sTkRQVQ9Jrrxv6van6/VmfPzxQYEnJsbaAP4i/+3h0r0UmSL79I7NU7f8Uv75BedcfRMhfV8/MaBH5D8IjujI+KUgU8ueazfNmcJqRHeH5MrVZsWKLwW/nD8wAHuIzF2TR0l0DbOFc16KFUpExpjKO+af532Cwv2zNyyQMVFkDt35QqyJrEvnbpt84o59YULSWBoaVnBeA/RKhWTsS5kN5cAcnctsz82VPrxDOKw+0GswXZ9zBAACPYn7mDjzffr0nycfWfZgeEXYWDIv6sLh/R6HdZUoE7P4dKZqOh8CQI16Ixpv3Zlau9GrFx/MB1W8SLmhR1UBickiX1jnIP8AZoAxHRpqal6pRNc/7yCEgcGumsx7Zt51UlC/DRnef9mtXIEyQWVW05m5LinOD0UQWefb4sjcBYDCbDholvalDTTME4TawWIRRFMRn7o+STXkyhfozQMghu7PGk9lXpk16wz3Zo7p+cqhRz4pPqzO3fGDFQCKYXi0SIFr8VLAUR3lOEJH+5YF76urkwDorl3gzLdnoD59vmuG2WWHEIZtxBzHxc1wZJhjzjZrbdUoYd8p5+587nDOW1UVQ9QBDl5mPExR1AXDhgRmw5VCGaIKmyhijozhyFiOjWFbYbZGiLZlp83Muztl65uvzGLIB71hIsRuj7yrZE70yBVW5WXOgDcqMAbtyG6t8AEmXpzZ6iACh+6If3pk5MqPTk6OJXn3OFLfeBIRQ0EHe1R916T6F1XBPNtFiRhO3C8R6TYSNWqMy3ozYiVWFfLAjEYyoCy76vU85f3QyZming4ZLlPsIvTKqgpvTGS8T74Cl/66EgbDgj/5kF+JFKxAh4V9R9sVVOm+TKufoL5yEIs6MRydfGDXvh8Bbv1ybgOuWDGs4+NX+O+FAV/KOEoKGBI4/2nr7btH6tc+ScznhchHWPrdixNrKmf49tBn19U3fkAi2W0TGmWiTSJOKWRAzzdmfDaee9QjbRO4mtsuqirGREa1c87mqVs/fahSrTvrl1ff/9Bt2wFg0bKmBfA9t/RuCI9oCxH/CFSD74/Aql6ZzDni9MHJx2/Zfchr1JtDE1vGpqFKoFtAIt8QDksQzh9BMPHvratvfMsDrbGt+ccjI80B22lf7Sj5wuTDm7bkUZ1SAfsqKl+alu5msud7TX3OWkTEXjpquPJ2leQtnPJzxtiVYSrgwg74sHIo8MAjN397fX3jpDH2Uue7Lzs03reFOd64fvi6CGz+q8b7vrNvX8UvsWYZGz5PgXcz2StGhq9/02n1b9/7wAN7DIDvea2TfAUHEv6CsvxyobAk6sVwfDzH7psXDV93bYXjr83Fe6bTdFFsvFvDZN9giG+Yln3/DOibRjfcaCYAN0vpvQPCO5jtSlUn2fstWTRV5uhVELd5/fDGz0HxNKAnaXv/60206FSfdC4D8OYk2UMvVwU8ai0nTyUiY/8ghKl4XoYFkfOJJ1CFmVeKphJcK3jekR2xfpLIEPUxGLFIqsbEV8G7hzE3sOW4itlCTC1i80Vm+7PEbEndr46Pj/s4XnZYm4hAaszBtlA2r4Jm6dt/73znEWNikzu6CcQiiRL4dGLzN23pTNHcwEOx91NG+UHL0e2quobJXnbhudddMjEx5sII+1PTqrjZmJjR55cj8pIKES0xpvIea6sfNrb6biZzapLuT4ytvmmkfs3PbN16e6foKy0VMBvVNhoNs/nhmx5T9bdGtmY0TBIvspoJLl+vwY0BZYr4IHdFP7Pa+7fcOu7c7BeiaCBCmEDedfQ51/YgigzbU5miM4j5OJFUvE+ccx1PHL1hpH716+a5NRZ+OGQWVNJG4wputcYTBa7KQnKFaAtRSEZIhcisYhOdTWRPzkKBXsWnTAbk9cMAMDzc8o1Gw6A288k0nf26tbVcprwhsKqqc22XujnnXNsFloQVcZ7IfOKSs645JetZbKmAfWwxLg00zByO+3DqZr8c28E4D6pnscjs7R4kquqsrbEXd79C9gDkoEgBOFV1RS8G0CStVd+Vurl7rR2MMzvQqcKHFTVEvHrvxfmwujd134EV2QFD4I8UHSfZYMFpyKNyGl6z5Q4jl280GuYfW7d+2fnOlcyGcyYsDDxI1Yn3zot4r1AfxipKoo4iO/DW9cNXXzQ+Pu537qzT5OQdKSP5aSfJP1kzEGfhPxeekyJLqjDB1iTNoirGmspqiXhd95YLyBKW+1iQ5/t/l59HkB8IBQSg47hTWq2xJDH8ttS1/9yairG2aogsU5asYjgyUTRgxXe+VPH2DQRMVuLF1pg4sqYaR7ZmAY0AIMzMv1EnJz++77lO+ibv258gmNnI1qw1cXZdw+E/NoaMsSY2ka1ZZmMTN/N5kHy0G8BXGgjnVqoh2F+Nsr9r3h86NaynhLd9Wlz6JlF50JqqsbZqmSMO+sLMnJWDrbG2aq2tWgDbne98QKu1x4EmB1u5yfe3PvWszh7Y4KTzaSIrocxxdq0clnN5AHoykZl/e/+WTX8VBmioRHbgIFmYzVLnuE+WTqLRAjJXIztgITpwrBSQjuF9FADWn/srb4TqzwN6CVSXA5QQ0eMC+rPJLYOfBsZk5OxrL7Rx5RKXdpSYmNlQh/3nHnxw0zOFiEZ3pap19Y1nGOYGKX5UIWcAugwgo4qUgD0gfoKJvkakn/+Hh2+eBIAmmjyWZUQbtpd633HabZAMgggn/s/u23r7fhwmQzhPLB0dHbUzuy/6SZC+TVUuBLAqLIgEQDEL0A4iephAd7P6z3+ztWnPIV08AC6qX3MBOPpZQDao6ikAahqSHb5LxA9D8DeUdD5739bb9+dluGjtteuJqxu8a/s8jYsZEEiasv3Dhx66eSaX5fzzrznOpvgFIjbZgJtIIMZWjXcz/3fzI7c/cITvQnlZKGB2r96C3vm8CSKX5EtczFfWI7nm/Nck1OvNuOYOLGbbtgaVpHL84v396+DlE4NeuAd7cHZzSJroeFdhTlQHls7dd9/Y/n478pBzQ6iBRt9rwbKFJKvWqiyZXbPvi1uv6Rzu3i8nHPNRUwMNg0bowooD29HRG01v1aWQMt8/qj7cikwHv6ftyL8/+F5Hds+FGwPQwKGcxI3GnWbnzinKV9E6/OXyMh9chiaafM+C3x1Wlvl2IB0q6/nQz/EHQAH7731U5qXOS6Z5sea9Fl0i33cZjsa84BIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlSpQoUaJEiRIlfsDw/wFWqLVPlgegSAAAAABJRU5ErkJggg==";

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const todayISO = () => new Date().toISOString().slice(0, 10);
const fmtDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
};
const initials = (name = "") =>
  name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase() || "").join("");

const EMPTY_STATE = { students: [], shiurim: [], attendance: [], observations: [], followups: [], goals: [] };

/* Preloaded roster — added directly since the CSV file picker wasn't working
   in this environment. Loadable with one tap from the Dashboard. */
const PRELOADED_STUDENTS = [
  { "name": "Harel Achial", "hebrewName": "", "whatsapp": "8187485587", "parentContact": "Father: 7477742361 / ramiachial@gmail.com | Mother: 7862165041 / shirliachial@gmail.com" },
  { "name": "Dvir Achial", "hebrewName": "", "whatsapp": "8182058036", "parentContact": "Father: 7477742361 / ramiachial@gmail.com | Mother: 7862165041 / shirliachial@gmail.com" },
  { "name": "Emanuel Aguvayev", "hebrewName": "", "whatsapp": "9295803223", "parentContact": "Father: 9174028725 / vadimny@yahoo.com | Mother: 9174027210 / bellana.laven@gmail.com" },
  { "name": "Ezra Ahlers", "hebrewName": "", "whatsapp": "8287120862", "parentContact": "Father: 8282319837 / jordanahlers1@gmail.com | Mother: 8282310900 / ahlers828@gmail.com" },
  { "name": "Itamar Azulay", "hebrewName": "", "whatsapp": "4243945410", "parentContact": "Father: 8182070507 / Haimazulay1975@gmail.com | Mother: 8188187440 / revitalizedesign@gmail.com" },
  { "name": "Michael Bamberger", "hebrewName": "", "whatsapp": "3232326465", "parentContact": "Mother: 32489990495" },
  { "name": "Eliahu Behnam", "hebrewName": "", "whatsapp": "5166039910", "parentContact": "" },
  { "name": "Elad Bell", "hebrewName": "", "whatsapp": "6173202840", "parentContact": "Father: 7813664393 / Jeremybell52@gmail.com | Mother: 6173202840 / Galitbell1@gmail.com" },
  { "name": "Binyamin Black", "hebrewName": "", "whatsapp": "447591743456", "parentContact": "Mother: 447564244816 / Debrabloomblack12@gmail.com" },
  { "name": "Daniel Boruchov", "hebrewName": "", "whatsapp": "7185777258", "parentContact": "Father: 3476598576 / Salboru@hotmail.com | Mother: 9179605022 / mboruchov@hotmail.com" },
  { "name": "Asher Bressel", "hebrewName": "", "whatsapp": "6179356599", "parentContact": "Father: 6178214886 / bressel@gmail.com | Mother: 6173196466 / abressel21@gmail.com" },
  { "name": "Adam Brodsky", "hebrewName": "", "whatsapp": "7173151227", "parentContact": "Father: 7174218005 / bautotrimm@gmail.com | Mother: 7174218001 / jiligan123@aol.com" },
  { "name": "Amitai Burack", "hebrewName": "", "whatsapp": "5616098805", "parentContact": "Father: 5618593062 / stevenburackdo@gmail.com | Mother: 618434294 / daniburack@gmail.com" },
  { "name": "David Cairns", "hebrewName": "", "whatsapp": "5873366434", "parentContact": "Father: 7807187925 / Kidkosher@gmail.com | Mother: 7809196841 / Seriah.sth@gmail.com" },
  { "name": "David Cohen", "hebrewName": "", "whatsapp": "8184477232", "parentContact": "Father: 8182313622 / yezharcohen@gmail.com | Mother: 8188269086 / rosalynecohen@gmail.com" },
  { "name": "Yehuda Davidovici", "hebrewName": "", "whatsapp": "2014665950", "parentContact": "Father: 9179408649 / Ilandav7@gmail.com | Mother: 3148826861 / Rinadav7@gmail.com" },
  { "name": "Dani Durbach", "hebrewName": "", "whatsapp": "6479177649", "parentContact": "Father: 6474041776 / durbachr@gmail.com | Mother: 6474031776 / saradurbach@gmail.com" },
  { "name": "Ori Edri", "hebrewName": "", "whatsapp": "9545496826", "parentContact": "Father: 9548702328 / Lior_aust@yahoo.com | Mother: 9548120546 / Rachel_rabanian@yahoo.com" },
  { "name": "Ari Ehrenreich", "hebrewName": "", "whatsapp": "3058898262", "parentContact": "Father: 5169930510 / dkhu602@gmail.com | Mother: 9542401278 / Dbofshever@ytcte.org" },
  { "name": "Yosef Yisrael Eliezer", "hebrewName": "", "whatsapp": "8188228763", "parentContact": "Father: 8182820596 / Davideliezer80@gmail.com | Mother: 0549404772 / Carrenc96@gmail.com" },
  { "name": "Gavi Elkin", "hebrewName": "", "whatsapp": "3473959255", "parentContact": "Father: 8478307448 / mde@michaelelkin.com | Mother: 9176969126 / szenes.jennifer84@gmail.com" },
  { "name": "Yosef Epstein", "hebrewName": "", "whatsapp": "5613320257", "parentContact": "Father: 9515157901 / nissanepstein@gmail.com | Mother: 5614036870 / shnaidermonica@aol.com" },
  { "name": "Moshe Freedman", "hebrewName": "", "whatsapp": "6672733545", "parentContact": "Father: 4433101392 / steven_freedman@yahoo.com | Mother: 4109496454 / ycfreedman@yahoo.com" },
  { "name": "Daniel Frieden", "hebrewName": "", "whatsapp": "5166037397", "parentContact": "Father: 6467526228 / dfrieden@gmail.com | Mother: 5166439098 / gabs36@yahoo.com" },
  { "name": "Noah Fromen", "hebrewName": "", "whatsapp": "2019065402", "parentContact": "Father: 9177960222 / heshfro@yahoo.com" },
  { "name": "Jason Ganjian", "hebrewName": "", "whatsapp": "5167600374", "parentContact": "Father: 9174943858 / afshin1015@yahoo.com | Mother: 6462757400 / Jganjian5@yahoo.com" },
  { "name": "Jayden Gasner", "hebrewName": "", "whatsapp": "6465990052", "parentContact": "Father: 8456611053 / gasner.ari@gmail.com | Mother: 9174536709 / ariella.gasner@gmail.com" },
  { "name": "Eli Gelb", "hebrewName": "", "whatsapp": "8478635195", "parentContact": "Father: 8474524386 / gelb@dr.com | Mother: 7737193827 / XXXXXXXXXX" },
  { "name": "Ezra Gelfand", "hebrewName": "", "whatsapp": "3473855492", "parentContact": "Father: 9176274400 | Mother: 9174208538 / Rachelgelf@yahoo.com" },
  { "name": "Yinnon Gellman", "hebrewName": "", "whatsapp": "9293722448", "parentContact": "Father: 7189864504 / safewaylocksmithinc@yahoo.com | Mother: 7185788120 / mgellman70@yahoo.com" },
  { "name": "Aviel Ginsbury", "hebrewName": "", "whatsapp": "447908971743", "parentContact": "Father: 447817256828 / dangins654@aol.com | Mother: 447970958277 / nginsbury@yahoo.co.uk" },
  { "name": "Nathan Glatt", "hebrewName": "", "whatsapp": "447498442307", "parentContact": "Mother: 447944039562 / louigla@yahoo.co.uk" },
  { "name": "Uriel Glatt", "hebrewName": "", "whatsapp": "447498440307", "parentContact": "Mother: 447944039562 / louigla@yahoo.co.uk" },
  { "name": "Eli Gozarkhah", "hebrewName": "", "whatsapp": "8186180739", "parentContact": "Father: 3103835345 / ariinla@yahoo.com | Mother: 8183886144" },
  { "name": "Elishama Gross", "hebrewName": "", "whatsapp": "9044691615", "parentContact": "Father: 9044156731 / jgross@bhnorthflorida.com | Mother: 9047088044 / chaigross@yahoo.com" },
  { "name": "Samuel Hirshbein", "hebrewName": "", "whatsapp": "7867738348", "parentContact": "Father: 3056100010 / Motty63@gmail.com | Mother: 3056100020 / Lottybaum@gmail.com" },
  { "name": "Michael Iliev", "hebrewName": "", "whatsapp": "6478043467", "parentContact": "Father: 6477056110 / mesema777@gmail.com | Mother: 4167823843 / a.shapiroo1968@gmail.com" },
  { "name": "Yoni Joseph", "hebrewName": "", "whatsapp": "447553249017", "parentContact": "Father: 447909976579 / jasonjoseph@hotmail.co.uk | Mother: 447974539481 / chanijoseph@hotmail.co.uk" },
  { "name": "Shlomo Kaganoff", "hebrewName": "", "whatsapp": "8622819226", "parentContact": "Father: 6469380471 / ykaganoff@gmail.com | Mother: 7187537459 / miriamdbk@gmail.com" },
  { "name": "David Kempner", "hebrewName": "", "whatsapp": "2406019922", "parentContact": "Father: 2405050761 / benjay@gmail.com | Mother: 2405050760 / rissak@gmail.com" },
  { "name": "Elliot Klein", "hebrewName": "", "whatsapp": "4479087369", "parentContact": "Mother: 4477088234 / office@lionrule.com" },
  { "name": "Noah Krupp", "hebrewName": "", "whatsapp": "6472846624", "parentContact": "Father: 6473477317 / maurykrupp1@gmail.com | Mother: 6479820651 / jennabitbol@yahoo.ca" },
  { "name": "Yehuda Lichaa", "hebrewName": "", "whatsapp": "3107290066", "parentContact": "Father: 3109889703 / lichaa@gmail.com | Mother: 3109889704 / yaellichaa@gmail.com" },
  { "name": "Michael Lugassy", "hebrewName": "", "whatsapp": "9545163165", "parentContact": "Father: 9542431786 / shailagaci@mac.com | Mother: 7542042834 / lugassylove@icloud.com" },
  { "name": "David Lunski", "hebrewName": "", "whatsapp": "5613328461", "parentContact": "Father: 5615263586 / lunski@gmail.com | Mother: 5615019327 / lunski.m@gmail.com" },
  { "name": "Nerya Maman", "hebrewName": "", "whatsapp": "9712809310", "parentContact": "Father: 9713006519 / odedmmn@gmail.com | Mother: 9714442609 / odedliatmaman@gmail.com" },
  { "name": "Yoni Mason", "hebrewName": "", "whatsapp": "447942284320", "parentContact": "Father: 447968815271 / stevenmason7@hotmail.com | Mother: 447966934214 / dinamason613@gmail.com" },
  { "name": "Yaakov Milgram", "hebrewName": "", "whatsapp": "9175448189", "parentContact": "Father: 9175611582 / Rabbidmilgram@gmail.com | Mother: 9292157065 / Mirskids123@gmail.com" },
  { "name": "Eitan Mirzakandov", "hebrewName": "", "whatsapp": "9296334554", "parentContact": "Father: 2124448933 / uri3777@yahoo.com | Mother: 7182163177 / rafailovay@aol.com" },
  { "name": "Netanel Murdakhayov", "hebrewName": "", "whatsapp": "3476327937", "parentContact": "Father: 7186643721 | Mother: 7188778429 / earonbayev@yahoo.com" },
  { "name": "Joseph Nassim", "hebrewName": "", "whatsapp": "447367508268", "parentContact": "Father: 447309880101 / bnassim@hotmail.co.uk" },
  { "name": "Gavriel Perlman", "hebrewName": "", "whatsapp": "3476774041", "parentContact": "Father: 3476930928 / sonyperlman@gmail.com | Mother: 3476930608 / yaelli613@gmail.com" },
  { "name": "Micah Peyman", "hebrewName": "", "whatsapp": "3105958556", "parentContact": "Father: 3108042882 / raminpr26@gmail.com | Mother: 3109232758 / myclosetgenie@yahoo.com" },
  { "name": "Aaron Pshemish", "hebrewName": "", "whatsapp": "6475136405", "parentContact": "Father: 4168386404 / Ypshemish@rogers.com | Mother: 4168386408 / Cjmpshemish@rogers.com" },
  { "name": "Daniel Rakhmanov", "hebrewName": "", "whatsapp": "", "parentContact": "" },
  { "name": "Moshe Robinson", "hebrewName": "", "whatsapp": "9293324964", "parentContact": "Father: 9179238432 / yrobinson@gmail.com | Mother: 9179221317 / rivkarobinson@gmail.com" },
  { "name": "Joseph Sacks", "hebrewName": "", "whatsapp": "4128639332", "parentContact": "Father: 4122253231 / ABBISHAYSACKS@GMAIL.COM | Mother: 4122154611 / RUBIA711@GMAIL.COM" },
  { "name": "Wyatt Sanders", "hebrewName": "", "whatsapp": "5132125406", "parentContact": "Father: 5134604067 / josh.tomaino@gmail.com | Mother: 5134604067 / gailyasanders@gmail.com" },
  { "name": "Asher Schwartz", "hebrewName": "", "whatsapp": "3175154539", "parentContact": "Mother: 3177286770 / Shelleyjc85@gmail.com" },
  { "name": "Zevi Shnayderman", "hebrewName": "", "whatsapp": "4699013178", "parentContact": "Father: 2146090707 / mschnayd@gmail.com | Mother: 4693609822 / shrayber.yana@gmail.com" },
  { "name": "Yaakov Shotkin", "hebrewName": "", "whatsapp": "9734934188", "parentContact": "Father: 9733306355 / Shotkin@gmail.com | Mother: 9737771837 / Shanishotkin@gmail.com" },
  { "name": "Mendel Sklar", "hebrewName": "", "whatsapp": "3474666763", "parentContact": "Father: 867043595 | Mother: 3479516099 / Chanagreenwald613@gmail.com" },
  { "name": "Itai Sogaokar", "hebrewName": "", "whatsapp": "4372652244", "parentContact": "Father: 6477745718 / sharonisaac12@gmail.com | Mother: 6476070199 / mencha3020@gmail.com" },
  { "name": "Daniel Solomon", "hebrewName": "", "whatsapp": "447947496753", "parentContact": "Father: 447968561321 / solomonbrothers@hotmail.com | Mother: 447951055681 / louisesolomonjfit@hotmail.co.uk" },
  { "name": "Mendy Stark", "hebrewName": "", "whatsapp": "6469884314", "parentContact": "Father: 7189609793 / jstark3nyc@gmail.com | Mother: 6467530477 / april00ny@gmail.com" },
  { "name": "Levi Suissa", "hebrewName": "", "whatsapp": "7864497871", "parentContact": "Father: 7869420966 / Danyswissa@yahoo.com | Mother: 7863446863 / Edery.delphine@gmail.com" },
  { "name": "Binyamin Valdez", "hebrewName": "", "whatsapp": "3239013082", "parentContact": "Father: 3239013082 / joseph26349@gmail.com | Mother: 8188388790 / Joseph26349@gmail.com" },
  { "name": "Avishai Weiman", "hebrewName": "", "whatsapp": "3149731704", "parentContact": "Father: 3148146629 / maxtorah@gmail.com | Mother: 3149736559 / chavamom@gmail.com" },
  { "name": "Moishy Weinstein", "hebrewName": "", "whatsapp": "4477089064", "parentContact": "Father: 44784641483 / dovweinas@gmail.com | Mother: 447482540601 / weinstein.sarah140@gmail.com" },
  { "name": "Matan Zagory", "hebrewName": "", "whatsapp": "9542493772", "parentContact": "Mother: 9542534499 / dbrodny@aol.com" },
  { "name": "Jonathan Zirkiyev", "hebrewName": "", "whatsapp": "3474727438", "parentContact": "Father: 3477531033 / zirkiyev@gmail.com | Mother: 3475586823" }
];

function downloadCSV(filename, rows) {
  if (!rows || rows.length === 0) return;
  const headers = Object.keys(rows[0]);
  const escape = (v) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h])).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function resizeImageFile(file, maxDim = 220, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/* ------------------------------------------------------------------ */
/*  Global style block                                                */
/* ------------------------------------------------------------------ */
function GlobalStyle() {
  return (
    <style>{`
      * { box-sizing: border-box; }
      .dos-root { font-family: ${FONT_BODY}; color: ${T.ink}; background: ${T.bg}; }
      .dos-display { font-family: ${FONT_DISPLAY}; }
      .dos-scrollbar::-webkit-scrollbar { width: 6px; }
      .dos-scrollbar::-webkit-scrollbar-thumb { background: ${T.border}; border-radius: 4px; }
      .dos-btn { transition: transform .12s ease, box-shadow .12s ease, background .12s ease; }
      .dos-btn:active { transform: scale(0.97); }
      .dos-card { transition: box-shadow .15s ease, transform .15s ease; }
      .dos-card:active { transform: scale(0.99); }
      .dos-stamp { transition: transform .15s cubic-bezier(.34,1.56,.64,1), box-shadow .15s ease; }
      .dos-stamp.active { transform: rotate(-4deg) scale(1.05); }
      .dos-fade-in { animation: dosFadeIn .25s ease both; }
      @keyframes dosFadeIn { from { opacity: 0; transform: translateY(6px);} to { opacity: 1; transform: translateY(0);} }
      input, select, textarea { font-family: ${FONT_BODY}; }
      input:focus, select:focus, textarea:focus, button:focus-visible {
        outline: 2px solid ${T.brass}; outline-offset: 1px;
      }
      @media (prefers-reduced-motion: reduce) {
        .dos-btn, .dos-card, .dos-stamp, .dos-fade-in { animation: none !important; transition: none !important; }
      }
      @media print {
        body * { visibility: hidden; }
        .dos-print-area, .dos-print-area * { visibility: visible; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .dos-print-area { position: absolute; top: 0; left: 0; width: 100%; padding: 24px; }
        .dos-no-print { display: none !important; }
      }
    `}</style>
  );
}

/* ------------------------------------------------------------------ */
/*  Small building blocks                                              */
/* ------------------------------------------------------------------ */
function TopBar({ title, onBack, right }) {
  return (
    <div
      style={{
        background: T.ink,
        color: T.surface,
        padding: "16px 16px 14px",
        display: "flex",
        alignItems: "center",
        gap: 10,
        position: "sticky",
        top: 0,
        zIndex: 20,
        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
      }}
    >
      {onBack ? (
        <button
          onClick={onBack}
          className="dos-btn"
          aria-label="Back"
          style={{
            background: "rgba(255,255,255,0.12)",
            border: "none",
            borderRadius: 999,
            width: 34,
            height: 34,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: T.surface,
            cursor: "pointer",
            flexShrink: 0,
          }}
        >
          <ChevronLeft size={20} />
        </button>
      ) : (
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 999,
            background: T.surface,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            overflow: "hidden",
          }}
        >
          <img src={LOGO_DATA_URI} alt="Derech" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          className="dos-display"
          style={{ fontSize: 19, fontWeight: 700, letterSpacing: 0.3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}
        >
          {title}
        </div>
      </div>
      {right}
    </div>
  );
}

function Chip({ children, tone = "neutral", size = "sm" }) {
  const tones = {
    neutral: { bg: T.surfaceAlt, color: T.inkSoft, border: T.border },
    sage: { bg: T.sageBg, color: T.sage, border: T.sage },
    brick: { bg: T.brickBg, color: T.brick, border: T.brick },
    brass: { bg: "#F1E4CC", color: T.brassDark, border: T.brass },
  };
  const c = tones[tone];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        background: c.bg,
        color: c.color,
        border: `1px solid ${c.border}33`,
        borderRadius: 999,
        padding: size === "sm" ? "3px 9px" : "5px 12px",
        fontSize: size === "sm" ? 12 : 13,
        fontWeight: 600,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}

function Avatar({ name, size = 40, flagged, photo }) {
  const style = {
    width: size,
    height: size,
    borderRadius: "50%",
    color: T.surface,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 700,
    fontSize: size * 0.38,
    flexShrink: 0,
    fontFamily: FONT_DISPLAY,
    position: "relative",
    overflow: "hidden",
    boxShadow: flagged ? `0 0 0 2px ${T.surface}, 0 0 0 4px ${T.brick}` : "none",
  };
  if (photo) {
    return (
      <div style={{ ...style, background: T.surfaceAlt }}>
        <img src={photo} alt={name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </div>
    );
  }
  return (
    <div style={{ ...style, background: `linear-gradient(135deg, ${T.brass}, ${T.brassDark})` }}>
      {initials(name) || "?"}
    </div>
  );
}

function PrimaryButton({ children, onClick, icon: Icon, tone = "brass", full, type = "button", disabled }) {
  const tones = {
    brass: { bg: T.brass, fg: T.surface },
    ink: { bg: T.ink, fg: T.surface },
    sage: { bg: T.sage, fg: T.surface },
    brick: { bg: T.brick, fg: T.surface },
    ghost: { bg: T.surface, fg: T.ink },
  };
  const c = tones[tone];
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className="dos-btn"
      style={{
        background: disabled ? T.borderSoft : c.bg,
        color: disabled ? T.inkFaint : c.fg,
        border: tone === "ghost" ? `1px solid ${T.border}` : "none",
        borderRadius: 12,
        padding: "12px 18px",
        fontSize: 15,
        fontWeight: 700,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        cursor: disabled ? "default" : "pointer",
        width: full ? "100%" : "auto",
      }}
    >
      {Icon && <Icon size={17} />}
      {children}
    </button>
  );
}

function Field({ label, children }) {
  return (
    <label style={{ display: "block", marginBottom: 14 }}>
      <div style={{ fontSize: 12.5, fontWeight: 700, color: T.inkSoft, marginBottom: 5, textTransform: "uppercase", letterSpacing: 0.4 }}>
        {label}
      </div>
      {children}
    </label>
  );
}

const inputStyle = {
  width: "100%",
  padding: "10px 12px",
  borderRadius: 9,
  border: `1px solid ${T.border}`,
  background: T.surface,
  fontSize: 15,
  color: T.ink,
};

function Section({ title, children, icon: Icon, action }) {
  return (
    <div style={{ background: T.surface, borderRadius: 14, border: `1px solid ${T.borderSoft}`, marginBottom: 14, overflow: "hidden" }}>
      <div
        style={{
          padding: "12px 16px",
          borderBottom: `1px solid ${T.borderSoft}`,
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: T.surfaceAlt,
        }}
      >
        {Icon && <Icon size={15} color={T.brassDark} />}
        <div className="dos-display" style={{ fontSize: 14.5, fontWeight: 700, color: T.ink, flex: 1, letterSpacing: 0.2 }}>
          {title}
        </div>
        {action}
      </div>
      <div style={{ padding: 16 }}>{children}</div>
    </div>
  );
}

function EmptyState({ label, sub }) {
  return (
    <div style={{ textAlign: "center", padding: "18px 8px", color: T.inkFaint }}>
      <div style={{ fontSize: 14, fontWeight: 600 }}>{label}</div>
      {sub && <div style={{ fontSize: 12.5, marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Derived data helpers                                               */
/* ------------------------------------------------------------------ */
function studentAttendancePct(state, studentId, days = 30) {
  const s = state.students.find((x) => x.id === studentId);
  if (!s) return null;
  const cutoff = Date.now() - days * 86400000;
  const sessions = state.attendance.filter((a) => a.shiurId === s.shiurId && new Date(a.date).getTime() >= cutoff);
  if (sessions.length === 0) return null;
  const absentCount = sessions.filter((a) => a.absentIds.includes(studentId)).length;
  return Math.round(((sessions.length - absentCount) / sessions.length) * 100);
}

function studentLateCount(state, studentId, days = 30) {
  const s = state.students.find((x) => x.id === studentId);
  if (!s) return 0;
  const cutoff = Date.now() - days * 86400000;
  return state.attendance.filter((a) => a.shiurId === s.shiurId && new Date(a.date).getTime() >= cutoff && (a.lateIds || []).includes(studentId)).length;
}

function shiurAttendancePct(state, shiurId) {
  const sessions = state.attendance.filter((a) => a.shiurId === shiurId);
  const roster = state.students.filter((s) => s.shiurId === shiurId);
  if (sessions.length === 0 || roster.length === 0) return null;
  let possible = 0, present = 0;
  sessions.forEach((sess) => {
    roster.forEach((st) => {
      possible += 1;
      if (!sess.absentIds.includes(st.id)) present += 1;
    });
  });
  return possible ? Math.round((present / possible) * 100) : null;
}

function daysSince(iso) {
  if (!iso) return null;
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
}

/* ------------------------------------------------------------------ */
/*  Fuzzy / typo-tolerant search                                       */
/* ------------------------------------------------------------------ */
function normalizeSearchStr(s) {
  return (s || "")
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

function levenshteinDistance(a, b) {
  const m = a.length, n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = a[i - 1] === b[j - 1]
        ? prev[j - 1]
        : 1 + Math.min(prev[j - 1], prev[j], cur[j - 1]);
    }
    prev = cur;
  }
  return prev[n];
}

// Scores how well a search query matches a student. Handles typos, partial
// words, and words typed in any order (e.g. "cohn dav" still finds "David Cohen").
// Returns -1 for "no match", otherwise a higher number is a better match.
function studentSearchScore(query, student) {
  const q = normalizeSearchStr(query);
  if (!q) return 0;
  const fieldValues = [student.name, student.hebrewName, student.whatsapp].filter(Boolean).map(normalizeSearchStr);
  if (fieldValues.length === 0) return -1;
  const queryWords = q.split(/\s+/).filter(Boolean);

  let total = 0;
  for (const w of queryWords) {
    let best = -1;
    for (const field of fieldValues) {
      if (field === w) { best = Math.max(best, 100); continue; }
      const tokens = field.split(/\s+/).filter(Boolean);
      for (const tok of tokens) {
        if (tok === w) { best = Math.max(best, 100); continue; }
        if (tok.startsWith(w)) { best = Math.max(best, 85); continue; }
        if (field.includes(w)) { best = Math.max(best, 60); continue; }
        const dist = levenshteinDistance(w, tok);
        const tolerance = w.length <= 3 ? 1 : w.length <= 6 ? 2 : 3;
        if (dist <= tolerance) best = Math.max(best, 45 - dist * 8);
      }
    }
    if (best < 0) return -1; // this word didn't match anything -> whole query fails
    total += best;
  }
  return total;
}

function lastAttendanceDateForShiur(state, shiurId) {
  const sessions = state.attendance.filter((a) => a.shiurId === shiurId).sort((a, b) => (a.date < b.date ? 1 : -1));
  return sessions[0]?.date || null;
}

function shiurObservationCountRecent(state, shiurId, days = 14) {
  const cutoff = Date.now() - days * 86400000;
  const studentIds = new Set(state.students.filter((s) => s.shiurId === shiurId).map((s) => s.id));
  return state.observations.filter((o) => studentIds.has(o.studentId) && new Date(o.date).getTime() >= cutoff).length;
}

function lastObservationDate(state, studentId) {
  const obs = state.observations.filter((o) => o.studentId === studentId).sort((a, b) => (a.date < b.date ? 1 : -1));
  return obs[0]?.date || null;
}

function openFollowupCount(state, studentId) {
  return state.followups.filter((f) => f.studentId === studentId && f.status !== "Done").length;
}

function needsAttentionList(state) {
  return state.students.filter((s) => {
    if (s.needsAttention) return true;
    const pct = studentAttendancePct(state, s.id, 30);
    if (pct !== null && pct < 80) return true;
    const last = lastObservationDate(state, s.id);
    const ds = daysSince(last);
    if (state.students.length && (ds === null || ds > 14)) return true;
    return false;
  });
}

// Scores a student's overall risk for the yeshiva-wide evaluation report.
// Combines flag status, attendance, how long since they were last observed,
// and open follow-ups into one 0-6 score with plain-language reasons.
function studentRiskInfo(state, student) {
  const pct = studentAttendancePct(state, student.id, 30);
  const obsDays = daysSince(lastObservationDate(state, student.id));
  const openFups = openFollowupCount(state, student.id);
  const reasons = [];
  let score = 0;

  if (student.needsAttention) {
    score += 2;
    reasons.push(student.attentionCategory ? `Flagged: ${student.attentionCategory}` : "Flagged for attention");
  }
  if (pct !== null && pct < 70) { score += 2; reasons.push(`${pct}% attendance (30d)`); }
  else if (pct !== null && pct < 85) { score += 1; reasons.push(`${pct}% attendance (30d)`); }
  if (obsDays === null) { score += 1; reasons.push("Never observed"); }
  else if (obsDays > 21) { score += 1; reasons.push(`${obsDays}d since last observation`); }
  if (openFups > 0) { score += 1; reasons.push(`${openFups} open follow-up${openFups > 1 ? "s" : ""}`); }
  if (!student.shiurId) { reasons.push("No Shiur assigned"); }

  const level = score >= 3 ? "high" : score >= 1 ? "watch" : "ok";
  return { score, level, reasons, pct, obsDays, openFups };
}

/* ------------------------------------------------------------------ */
/*  HOME                                                                */
/* ------------------------------------------------------------------ */
function HomeView({ state, goto }) {
  const attn = needsAttentionList(state);
  const cards = [
    { key: "attendance", label: "Take Attendance", sub: "Mark who's here, tap who's not", icon: ClipboardCheck, tone: T.sage },
    { key: "addObservation", label: "Add Observation", sub: "Note something about a talmid", icon: MessageSquarePlus, tone: T.brass },
    { key: "students", label: "Talmidim", sub: `${state.students.length} students`, icon: Users, tone: T.ink },
    { key: "dashboard", label: "Dashboard", sub: "See who needs attention", icon: LayoutDashboard, tone: T.brick },
  ];
  return (
    <div className="dos-fade-in" style={{ padding: 16 }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 18, paddingTop: 4 }}>
        <img src={LOGO_DATA_URI} alt="Derech" style={{ width: 68, height: 68, objectFit: "contain", marginBottom: 6 }} />
        <div className="dos-display" style={{ fontSize: 13, fontWeight: 700, color: T.inkSoft, letterSpacing: 0.5, textTransform: "uppercase" }}>
          Talmid Tracker
        </div>
      </div>
      {attn.length > 0 && (
        <button
          onClick={() => goto("dashboard")}
          className="dos-btn"
          style={{
            width: "100%",
            textAlign: "left",
            background: T.brickBg,
            border: `1px solid ${T.brick}55`,
            borderRadius: 14,
            padding: "13px 16px",
            display: "flex",
            alignItems: "center",
            gap: 10,
            marginBottom: 16,
            cursor: "pointer",
          }}
        >
          <AlertTriangle size={20} color={T.brick} style={{ flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: 700, color: T.brick, fontSize: 14.5 }}>
              {attn.length} talmid{attn.length > 1 ? "im" : ""} need{attn.length === 1 ? "s" : ""} attention
            </div>
            <div style={{ fontSize: 12.5, color: T.brick, opacity: 0.85 }}>Tap to see who</div>
          </div>
        </button>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {cards.map((c) => (
          <button
            key={c.key}
            onClick={() => goto(c.key)}
            className="dos-btn dos-card"
            style={{
              background: T.surface,
              border: `1px solid ${T.borderSoft}`,
              borderRadius: 16,
              padding: "20px 14px",
              textAlign: "left",
              cursor: "pointer",
              boxShadow: "0 1px 3px rgba(38,54,74,0.06)",
            }}
          >
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 11,
                background: c.tone,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <c.icon size={20} color={T.surface} />
            </div>
            <div className="dos-display" style={{ fontWeight: 700, fontSize: 15.5, color: T.ink, marginBottom: 2 }}>
              {c.label}
            </div>
            <div style={{ fontSize: 12, color: T.inkFaint }}>{c.sub}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  ATTENDANCE FLOW                                                     */
/* ------------------------------------------------------------------ */
function StatusPicker({ status, onChange, size = "normal" }) {
  // status: "present" | "late" | "absent"
  const opts = [
    { key: "present", label: "P", color: T.sage, bg: T.sageBg },
    { key: "late", label: "L", color: T.brassDark, bg: "#F1E4CC" },
    { key: "absent", label: "A", color: T.brick, bg: T.brickBg },
  ];
  const dim = size === "small" ? 30 : 36;
  return (
    <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
      {opts.map((o) => {
        const active = status === o.key;
        return (
          <button
            key={o.key}
            onClick={() => onChange(o.key)}
            className={`dos-btn dos-stamp ${active ? "active" : ""}`}
            aria-label={o.label}
            style={{
              width: dim, height: dim, borderRadius: 9,
              border: `2px solid ${active ? o.color : T.borderSoft}`,
              background: active ? o.bg : T.surface,
              color: active ? o.color : T.inkFaint,
              fontWeight: 800, fontSize: 13, cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function statusOf(id, absentSet, lateSet) {
  if (lateSet.has(id)) return "late";
  if (absentSet.has(id)) return "absent";
  return "present";
}

function AttendanceView({ state, update, goto, recordedBy }) {
  const [shiurId, setShiurId] = useState(state.shiurim[0]?.id || "");
  const [seder, setSeder] = useState(SEDARIM[0]);
  const [date, setDate] = useState(todayISO());
  const [absent, setAbsent] = useState(new Set());
  const [late, setLate] = useState(new Set());
  const [saved, setSaved] = useState(false);

  const roster = state.students.filter((s) => s.shiurId === shiurId);

  const setStatus = (id, status) => {
    setAbsent((prev) => {
      const next = new Set(prev);
      status === "absent" ? next.add(id) : next.delete(id);
      return next;
    });
    setLate((prev) => {
      const next = new Set(prev);
      status === "late" ? next.add(id) : next.delete(id);
      return next;
    });
  };

  const markAllPresent = () => { setAbsent(new Set()); setLate(new Set()); };

  const save = () => {
    const session = { id: uid(), shiurId, seder, date, absentIds: Array.from(absent), lateIds: Array.from(late), recordedAt: Date.now(), recordedBy: recordedBy || "", source: "manual" };
    update((s) => ({ ...s, attendance: [...s.attendance, session] }));
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      goto("home");
    }, 900);
  };

  if (state.shiurim.length === 0) {
    return (
      <div style={{ padding: 16 }}>
        <EmptyState label="No Shiurim yet" sub="Add a Shiur first from the Dashboard." />
        <div style={{ marginTop: 12 }}>
          <PrimaryButton onClick={() => goto("dashboard")} full>Go to Dashboard</PrimaryButton>
        </div>
      </div>
    );
  }

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 100 }}>
      <button
        onClick={() => goto("photoAttendance")}
        className="dos-btn"
        style={{
          width: "100%", background: T.surfaceAlt, border: `1px dashed ${T.border}`, borderRadius: 12,
          padding: "10px 12px", display: "flex", alignItems: "center", gap: 8, cursor: "pointer", marginBottom: 14,
        }}
      >
        <Camera size={16} color={T.brassDark} />
        <span style={{ fontSize: 13, fontWeight: 700, color: T.ink }}>Or photograph a handwritten sheet</span>
      </button>
      <Section title="Class & Date" icon={ClipboardCheck}>
        <Field label="Shiur">
          <select style={inputStyle} value={shiurId} onChange={(e) => { setShiurId(e.target.value); setAbsent(new Set()); setLate(new Set()); }}>
            {state.shiurim.map((sh) => (
              <option key={sh.id} value={sh.id}>{sh.name}{sh.rebbe ? ` — ${sh.rebbe}` : ""}</option>
            ))}
          </select>
        </Field>
        <Field label="Seder">
          <select style={inputStyle} value={seder} onChange={(e) => setSeder(e.target.value)}>
            {SEDARIM.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" style={inputStyle} value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </Section>

      {roster.length === 0 ? (
        <EmptyState label="No students in this Shiur yet" />
      ) : (
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ fontSize: 13, color: T.inkSoft, fontWeight: 600 }}>
              {roster.length - absent.size - late.size} present · {late.size} late · {absent.size} absent
            </div>
            <button
              onClick={markAllPresent}
              className="dos-btn"
              style={{
                background: T.sageBg,
                color: T.sage,
                border: `1px solid ${T.sage}55`,
                borderRadius: 999,
                padding: "6px 14px",
                fontSize: 12.5,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Mark All Present
            </button>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {roster.map((s) => {
              const status = statusOf(s.id, absent, late);
              return (
                <div
                  key={s.id}
                  style={{
                    background: T.surface,
                    border: `1px solid ${status !== "present" ? (status === "absent" ? T.brick : T.brassDark) + "66" : T.borderSoft}`,
                    borderRadius: 13,
                    padding: "10px 12px",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                  }}
                >
                  <Avatar name={s.name} size={36} photo={s.photo} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.name}</div>
                  </div>
                  <StatusPicker status={status} onChange={(st) => setStatus(s.id, st)} />
                </div>
              );
            })}
          </div>
        </>
      )}

      <div style={{ position: "fixed", left: 0, right: 0, bottom: 64, padding: "10px 16px", background: `linear-gradient(to top, ${T.bg} 60%, transparent)` }}>
        <PrimaryButton onClick={save} full tone={saved ? "sage" : "ink"} icon={saved ? CheckCircle2 : Save} disabled={roster.length === 0}>
          {saved ? "Saved!" : "Save Attendance"}
        </PrimaryButton>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  ADD OBSERVATION                                                     */
/* ------------------------------------------------------------------ */
function prepareImageForOCR(file, maxDim = 1400, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#FFFFFF";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve({ dataUrl, base64: dataUrl.split(",")[1], mediaType: "image/jpeg" });
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function readAttendanceSheet(base64, mediaType, rosterNames, apiKey) {
  if (!apiKey) throw new Error("NO_API_KEY");
  const prompt = `You are reading a photo of a handwritten yeshiva attendance sheet. Here is the exact roster of student names for this class:
${rosterNames.map((n) => `- ${n}`).join("\n")}

Look at the handwritten marks next to each name (checkmarks, X's, circles, "L" for late, or similar) and determine who is present, who arrived late, and who is absent. Match each mark to the closest roster name, even with imperfect handwriting. A plain checkmark or "P" means present. An "L", a circled mark, or any note indicating a late arrival means late. An "X", a blank, or a clear absence mark means absent.

Respond with ONLY valid JSON, no prose, no markdown code fences, in exactly this shape:
{"results": [{"rosterName": "<exact name from the roster list above>", "status": "present" | "late" | "absent" | "unclear", "confidence": "high" | "low"}], "unmatched": ["<any handwritten name or mark on the sheet that doesn't match a roster name>"]}

Include every roster name in "results" exactly once. If a name has no visible mark at all, use "unclear" with "low" confidence.`;

  // Standalone (outside Claude's environment) — this calls Anthropic's API directly from the
  // browser using a key you provide in Settings. "anthropic-dangerous-direct-browser-access" is
  // Anthropic's documented opt-in for exactly this pattern; it means the key is visible to anyone
  // with access to this browser/device's developer tools, so only use a key you're comfortable
  // having live on staff devices.
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-5",
      max_tokens: 2000,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } },
            { type: "text", text: prompt },
          ],
        },
      ],
    }),
  });
  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(`API error ${response.status}: ${body.slice(0, 200)}`);
  }
  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === "text");
  if (!textBlock) throw new Error("No text in response");
  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

function PhotoAttendanceView({ state, update, goto, recordedBy, anthropicApiKey }) {
  const [shiurId, setShiurId] = useState(state.shiurim[0]?.id || "");
  const [seder, setSeder] = useState(SEDARIM[0]);
  const [date, setDate] = useState(todayISO());
  const [imageData, setImageData] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | reading | reviewing | error
  const [errorMsg, setErrorMsg] = useState("");
  const [results, setResults] = useState(null); // {name -> status}
  const [unmatched, setUnmatched] = useState([]);
  const [saved, setSaved] = useState(false);
  const fileRef = useRef();

  const roster = state.students.filter((s) => s.shiurId === shiurId);

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const prepped = await prepareImageForOCR(file);
      setImageData(prepped);
      setStatus("idle");
      setResults(null);
    } catch {
      setErrorMsg("Couldn't read that image. Try a different photo.");
      setStatus("error");
    }
  };

  const readSheet = async () => {
    if (!imageData || roster.length === 0) return;
    setStatus("reading");
    setErrorMsg("");
    try {
      const parsed = await readAttendanceSheet(imageData.base64, imageData.mediaType, roster.map((s) => s.name), anthropicApiKey);
      const statusMap = {};
      (parsed.results || []).forEach((r) => { statusMap[r.rosterName] = r; });
      setResults(statusMap);
      setUnmatched(parsed.unmatched || []);
      setStatus("reviewing");
    } catch (err) {
      if (err.message === "NO_API_KEY") {
        setErrorMsg("No API key set up yet. Add one in Dashboard → Settings to use photo reading, or enter attendance manually below.");
      } else if (!navigator.onLine) {
        setErrorMsg("You're offline — photo reading needs an internet connection. Enter attendance manually instead, or try again once you're back online.");
      } else {
        setErrorMsg("Couldn't read the sheet clearly. Try a clearer photo, better lighting, or enter attendance manually.");
      }
      setStatus("error");
    }
  };

  const [manualAbsent, setManualAbsent] = useState(new Set());
  const [manualLate, setManualLate] = useState(new Set());
  useEffect(() => {
    if (results) {
      const abs = new Set();
      const lat = new Set();
      roster.forEach((s) => {
        const r = results[s.name];
        if (r && r.status === "absent") abs.add(s.id);
        else if (r && r.status === "late") lat.add(s.id);
        else if (r && r.status === "unclear" && r.confidence === "low") abs.add(s.id);
      });
      setManualAbsent(abs);
      setManualLate(lat);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [results]);

  const setRowStatus = (id, st) => {
    setManualAbsent((prev) => { const next = new Set(prev); st === "absent" ? next.add(id) : next.delete(id); return next; });
    setManualLate((prev) => { const next = new Set(prev); st === "late" ? next.add(id) : next.delete(id); return next; });
  };

  const confirm = () => {
    const session = { id: uid(), shiurId, seder, date, absentIds: Array.from(manualAbsent), lateIds: Array.from(manualLate), recordedAt: Date.now(), recordedBy: recordedBy || "", source: "photo" };
    update((s) => ({ ...s, attendance: [...s.attendance, session] }));
    setSaved(true);
    setTimeout(() => { setSaved(false); goto("home"); }, 900);
  };

  if (state.shiurim.length === 0) {
    return <div style={{ padding: 16 }}><EmptyState label="No Shiurim yet" sub="Add a Shiur first from the Dashboard." /></div>;
  }

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 100 }}>
      <Section title="Class & Date" icon={ClipboardCheck}>
        <Field label="Shiur">
          <select style={inputStyle} value={shiurId} onChange={(e) => { setShiurId(e.target.value); setResults(null); setStatus("idle"); }}>
            {state.shiurim.map((sh) => <option key={sh.id} value={sh.id}>{sh.name}{sh.rebbe ? ` — ${sh.rebbe}` : ""}</option>)}
          </select>
        </Field>
        <Field label="Seder">
          <select style={inputStyle} value={seder} onChange={(e) => setSeder(e.target.value)}>
            {SEDARIM.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" style={inputStyle} value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </Section>

      {status !== "reviewing" && (
        <Section title="Photo of Attendance Sheet" icon={Camera}>
          <button
            onClick={() => fileRef.current?.click()}
            className="dos-btn"
            style={{ width: "100%", background: T.surfaceAlt, border: `2px dashed ${T.border}`, borderRadius: 12, padding: "18px 14px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, cursor: "pointer" }}
          >
            {imageData ? (
              <img src={imageData.dataUrl} alt="Attendance sheet" style={{ maxWidth: "100%", maxHeight: 220, borderRadius: 8, objectFit: "contain" }} />
            ) : (
              <>
                <Camera size={26} color={T.brassDark} />
                <span style={{ fontWeight: 700, fontSize: 14, color: T.ink }}>Tap to take or choose a photo</span>
              </>
            )}
          </button>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={handleFile} style={{ display: "none" }} />
          {imageData && (
            <div style={{ marginTop: 10 }}>
              <PrimaryButton onClick={readSheet} full icon={status === "reading" ? Loader2 : ImageIcon} disabled={status === "reading" || roster.length === 0}>
                {status === "reading" ? "Reading sheet..." : "Read Sheet"}
              </PrimaryButton>
            </div>
          )}
          {roster.length === 0 && <div style={{ fontSize: 12, color: T.brick, marginTop: 8 }}>No students in this Shiur yet.</div>}
          {status === "error" && <div style={{ background: T.brickBg, color: T.brick, borderRadius: 8, padding: 10, fontSize: 12.5, fontWeight: 600, marginTop: 10 }}>{errorMsg}</div>}
        </Section>
      )}

      {status === "reviewing" && results && (
        <>
          {unmatched.length > 0 && (
            <div style={{ background: T.brickBg, border: `1px solid ${T.brick}55`, borderRadius: 10, padding: 11, marginBottom: 12, fontSize: 12.5, color: T.brick }}>
              <strong>Couldn't confidently match:</strong> {unmatched.join(", ")}. Check these manually.
            </div>
          )}
          <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
            Review what the AI read below — tap any student to correct it, then confirm.
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ fontSize: 13, color: T.inkSoft, fontWeight: 600 }}>
              {roster.length - manualAbsent.size - manualLate.size} present · {manualLate.size} late · {manualAbsent.size} absent
            </div>
            <button onClick={() => { setManualAbsent(new Set()); setManualLate(new Set()); }} className="dos-btn" style={{ background: T.sageBg, color: T.sage, border: `1px solid ${T.sage}55`, borderRadius: 999, padding: "6px 14px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}>
              Mark All Present
            </button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {roster.map((s) => {
              const rowStatus = statusOf(s.id, manualAbsent, manualLate);
              const r = results[s.name];
              const lowConfidence = r && r.confidence === "low";
              return (
                <div key={s.id} style={{ background: T.surface, border: `1px solid ${rowStatus !== "present" ? (rowStatus === "absent" ? T.brick : T.brassDark) + "66" : T.borderSoft}`, borderRadius: 13, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10 }}>
                  <Avatar name={s.name} size={36} photo={s.photo} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14.5 }}>{s.name}</div>
                    {lowConfidence && <div style={{ fontSize: 10.5, color: T.brick }}>AI unsure — please check</div>}
                  </div>
                  <StatusPicker status={rowStatus} onChange={(st) => setRowStatus(s.id, st)} size="small" />
                </div>
              );
            })}
          </div>
          <div style={{ position: "fixed", left: 0, right: 0, bottom: 64, padding: "10px 16px", background: `linear-gradient(to top, ${T.bg} 60%, transparent)` }}>
            <PrimaryButton onClick={confirm} full tone={saved ? "sage" : "ink"} icon={saved ? CheckCircle2 : Save}>
              {saved ? "Saved!" : "Confirm Attendance"}
            </PrimaryButton>
          </div>
        </>
      )}
    </div>
  );
}

function AddObservationView({ state, update, goto, presetStudentId, enteredBy }) {
  const [studentId, setStudentId] = useState(presetStudentId || state.students[0]?.id || "");
  const [area, setArea] = useState(AREAS[0]);
  const [text, setText] = useState("");
  const [followUp, setFollowUp] = useState(false);
  const [followUpTask, setFollowUpTask] = useState("");

  const submit = () => {
    if (!studentId || !text.trim()) return;
    const obs = { id: uid(), studentId, date: todayISO(), area, text: text.trim(), followUp, enteredBy: enteredBy || "" };
    update((s) => {
      let next = { ...s, observations: [...s.observations, obs] };
      if (followUp && followUpTask.trim()) {
        next.followups = [...next.followups, { id: uid(), studentId, task: followUpTask.trim(), due: "", status: "Open", createdDate: todayISO() }];
      }
      return next;
    });
    goto("studentProfile", studentId);
  };

  if (state.students.length === 0) {
    return <div style={{ padding: 16 }}><EmptyState label="No students yet" sub="Add students from the Dashboard first." /></div>;
  }

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 90 }}>
      <Section title="New Observation" icon={MessageSquarePlus}>
        <Field label="Student">
          <select style={inputStyle} value={studentId} onChange={(e) => setStudentId(e.target.value)}>
            {state.students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field label="Area">
          <select style={inputStyle} value={area} onChange={(e) => setArea(e.target.value)}>
            {AREAS.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </Field>
        <Field label="What did you notice?">
          <textarea style={{ ...inputStyle, minHeight: 100, resize: "vertical" }} value={text} onChange={(e) => setText(e.target.value)} placeholder="Write freely — this becomes part of his timeline." />
        </Field>
        <label style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: followUp ? 12 : 0, cursor: "pointer" }}>
          <input type="checkbox" checked={followUp} onChange={(e) => setFollowUp(e.target.checked)} style={{ width: 18, height: 18 }} />
          <span style={{ fontSize: 14, fontWeight: 600 }}>This needs follow-up</span>
        </label>
        {followUp && (
          <Field label="Follow-up task">
            <input style={inputStyle} value={followUpTask} onChange={(e) => setFollowUpTask(e.target.value)} placeholder="e.g. Check in with him Sunday" />
          </Field>
        )}
      </Section>
      <PrimaryButton onClick={submit} full icon={Save} disabled={!text.trim()}>Save Observation</PrimaryButton>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  STUDENTS LIST                                                       */
/* ------------------------------------------------------------------ */
function StudentsListView({ state, goto, update }) {
  const [q, setQ] = useState("");
  const [mode, setMode] = useState("cards");
  const [sortKey, setSortKey] = useState("name");
  const [sortDir, setSortDir] = useState(1);
  const [showAddStudent, setShowAddStudent] = useState(false);
  const filtered = q.trim()
    ? state.students
        .map((s) => ({ s, score: studentSearchScore(q, s) }))
        .filter((x) => x.score >= 0)
        .sort((a, b) => b.score - a.score)
        .map((x) => x.s)
    : state.students;
  const shiurName = (id) => state.shiurim.find((sh) => sh.id === id)?.name || "No Shiur";

  const rows = filtered.map((s) => ({
    student: s,
    name: s.name,
    shana: s.shana || "",
    shiur: shiurName(s.shiurId),
    pct: studentAttendancePct(state, s.id, 30),
    lastObs: daysSince(lastObservationDate(state, s.id)),
    openFollowups: openFollowupCount(state, s.id),
    flagged: s.needsAttention ? 1 : 0,
  }));

  const sorted = [...rows].sort((a, b) => {
    let av = a[sortKey], bv = b[sortKey];
    if (av === null) av = -1;
    if (bv === null) bv = -1;
    if (typeof av === "string") return av.localeCompare(bv) * sortDir;
    return (av - bv) * sortDir;
  });

  const setSort = (key) => {
    if (sortKey === key) setSortDir((d) => -d);
    else { setSortKey(key); setSortDir(1); }
  };

  const exportCSV = () => downloadCSV(`talmidim-${todayISO()}.csv`, filtered.map((s) => ({
    Name: s.name, "Hebrew Name": s.hebrewName || "", Shana: s.shana || "", Shiur: shiurName(s.shiurId), WhatsApp: s.whatsapp || "",
    "Attendance % (30d)": studentAttendancePct(state, s.id, 30) ?? "", "Days Since Last Observation": daysSince(lastObservationDate(state, s.id)) ?? "",
    "Open Follow-ups": openFollowupCount(state, s.id), "Needs Attention": s.needsAttention ? "Yes" : "No",
    "Therapy Status": s.therapyStatus || "", "Parent Contact": s.parentContact || "",
  })));

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 30 }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <div style={{ position: "relative", flex: 1 }}>
          <Search size={16} color={T.inkFaint} style={{ position: "absolute", left: 12, top: 13 }} />
          <input
            style={{ ...inputStyle, paddingLeft: 34 }}
            placeholder="Search talmidim..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <button
          onClick={() => setShowAddStudent(true)}
          className="dos-btn"
          aria-label="Add student"
          style={{ background: T.ink, color: T.surface, border: "none", borderRadius: 9, width: 42, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
        >
          <Plus size={18} />
        </button>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 4, background: T.surfaceAlt, borderRadius: 9, padding: 3 }}>
          {["cards", "table"].map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className="dos-btn"
              style={{
                background: mode === m ? T.surface : "none",
                border: "none",
                borderRadius: 7,
                padding: "5px 12px",
                fontSize: 12.5,
                fontWeight: 700,
                color: mode === m ? T.ink : T.inkFaint,
                cursor: "pointer",
                boxShadow: mode === m ? "0 1px 2px rgba(0,0,0,0.08)" : "none",
              }}
            >
              {m === "cards" ? "Cards" : "Table"}
            </button>
          ))}
        </div>
        <button
          onClick={exportCSV}
          className="dos-btn"
          style={{ background: "none", border: `1px solid ${T.border}`, color: T.inkSoft, borderRadius: 8, padding: "6px 11px", fontSize: 12, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }}
        >
          <Download size={13} /> CSV
        </button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState label={state.students.length === 0 ? "No talmidim yet" : "No matches"} sub={state.students.length === 0 ? "Add students or import a CSV from the Dashboard." : ""} />
      ) : mode === "cards" ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map((s) => (
            <div
              key={s.id}
              className="dos-card"
              style={{
                background: T.surface,
                border: `1px solid ${T.borderSoft}`,
                borderRadius: 13,
                padding: "10px 12px",
                display: "flex",
                alignItems: "center",
                gap: 11,
              }}
            >
              <PhotoPicker student={s} size={40} onChange={(photo) => update && update((st) => ({ ...st, students: st.students.map((x) => (x.id === s.id ? { ...x, photo } : x)) }))} />
              <button
                onClick={() => goto("studentProfile", s.id)}
                className="dos-btn"
                style={{ flex: 1, minWidth: 0, background: "none", border: "none", padding: 0, textAlign: "left", cursor: "pointer" }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{s.name}</div>
                  {s.shana && <Chip tone="brass">{s.shana}</Chip>}
                </div>
                <div style={{ fontSize: 12, color: T.inkFaint }}>{shiurName(s.shiurId)}</div>
              </button>
              {s.needsAttention && <Flag size={16} color={T.brick} style={{ flexShrink: 0 }} />}
            </div>
          ))}
        </div>
      ) : (
        <div style={{ overflowX: "auto", border: `1px solid ${T.borderSoft}`, borderRadius: 12, background: T.surface }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, minWidth: 560 }}>
            <thead>
              <tr style={{ background: T.surfaceAlt, borderBottom: `1px solid ${T.borderSoft}` }}>
                {[
                  ["name", "Name"], ["shana", "Shana"], ["shiur", "Shiur"], ["pct", "Attend %"],
                  ["lastObs", "Days Since Obs"], ["openFollowups", "Open F/U"], ["flagged", "Flag"],
                ].map(([key, label]) => (
                  <th
                    key={key}
                    onClick={() => setSort(key)}
                    style={{ padding: "9px 10px", textAlign: "left", fontWeight: 700, color: T.inkSoft, cursor: "pointer", whiteSpace: "nowrap", userSelect: "none" }}
                  >
                    {label} {sortKey === key ? (sortDir === 1 ? "▲" : "▼") : ""}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map((r) => (
                <tr
                  key={r.student.id}
                  onClick={() => goto("studentProfile", r.student.id)}
                  style={{ borderBottom: `1px solid ${T.borderSoft}`, cursor: "pointer" }}
                >
                  <td style={{ padding: "8px 10px", fontWeight: 700, whiteSpace: "nowrap" }}>{r.name}</td>
                  <td style={{ padding: "8px 10px", color: T.inkSoft, whiteSpace: "nowrap" }}>{r.shana || "—"}</td>
                  <td style={{ padding: "8px 10px", color: T.inkSoft, whiteSpace: "nowrap" }}>{r.shiur}</td>
                  <td style={{ padding: "8px 10px", color: r.pct !== null && r.pct < 80 ? T.brick : T.inkSoft, fontWeight: r.pct !== null && r.pct < 80 ? 700 : 400 }}>
                    {r.pct === null ? "—" : `${r.pct}%`}
                  </td>
                  <td style={{ padding: "8px 10px", color: r.lastObs === null || r.lastObs > 14 ? T.brick : T.inkSoft }}>
                    {r.lastObs === null ? "never" : r.lastObs}
                  </td>
                  <td style={{ padding: "8px 10px" }}>{r.openFollowups || "—"}</td>
                  <td style={{ padding: "8px 10px" }}>{r.flagged ? <Flag size={14} color={T.brick} /> : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {showAddStudent && <AddStudentModal state={state} update={update} onClose={() => setShowAddStudent(false)} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  STUDENT PROFILE                                                     */
/* ------------------------------------------------------------------ */
function EditableText({ value, onSave, placeholder, minHeight = 70 }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value || "");
  useEffect(() => setVal(value || ""), [value]);

  if (editing) {
    return (
      <div>
        <textarea
          autoFocus
          style={{ ...inputStyle, minHeight, resize: "vertical" }}
          value={val}
          onChange={(e) => setVal(e.target.value)}
        />
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <button
            onClick={() => { onSave(val); setEditing(false); }}
            className="dos-btn"
            style={{ background: T.ink, color: T.surface, border: "none", borderRadius: 8, padding: "6px 14px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}
          >Save</button>
          <button
            onClick={() => { setVal(value || ""); setEditing(false); }}
            className="dos-btn"
            style={{ background: "transparent", color: T.inkSoft, border: `1px solid ${T.border}`, borderRadius: 8, padding: "6px 14px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}
          >Cancel</button>
        </div>
      </div>
    );
  }
  return (
    <div onClick={() => setEditing(true)} style={{ cursor: "text", fontSize: 14, lineHeight: 1.5, color: value ? T.ink : T.inkFaint, minHeight: 20 }}>
      {value || placeholder}
    </div>
  );
}

function PhotoPicker({ student, onChange, size = 62 }) {
  const inputRef = useRef();
  const [busy, setBusy] = useState(false);
  const badgeSize = size <= 44 ? 16 : 22;
  const badgeIconSize = size <= 44 ? 9 : 11;
  const pick = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await resizeImageFile(file);
      onChange(dataUrl);
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };
  return (
    <button
      onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}
      className="dos-btn"
      style={{ position: "relative", background: "none", border: "none", padding: 0, cursor: "pointer", flexShrink: 0 }}
      aria-label="Change photo"
    >
      <Avatar name={student.name} size={size} flagged={student.needsAttention} photo={student.photo} />
      <div
        style={{
          position: "absolute", bottom: -2, right: -2, width: badgeSize, height: badgeSize, borderRadius: "50%",
          background: T.brass, border: `2px solid ${T.bg}`, display: "flex", alignItems: "center", justifyContent: "center",
        }}
      >
        {busy ? <Loader2 size={badgeIconSize} color={T.surface} style={{ animation: "spin 1s linear infinite" }} /> : <Upload size={badgeIconSize} color={T.surface} />}
      </div>
      <input ref={inputRef} type="file" accept="image/*" capture="environment" onChange={pick} style={{ display: "none" }} />
    </button>
  );
}

function StudentProfileView({ state, update, goto, studentId }) {
  const s = state.students.find((x) => x.id === studentId);
  const [tab, setTab] = useState("overview");
  const [showEdit, setShowEdit] = useState(false);
  const [showFlag, setShowFlag] = useState(false);
  if (!s) return <div style={{ padding: 16 }}><EmptyState label="Student not found" /></div>;

  const shiur = state.shiurim.find((sh) => sh.id === s.shiurId);
  const pct = studentAttendancePct(state, s.id, 30);
  const obs = state.observations.filter((o) => o.studentId === s.id).sort((a, b) => (a.date < b.date ? 1 : -1));
  const fups = state.followups.filter((f) => f.studentId === s.id).sort((a, b) => (a.status === b.status ? 0 : a.status === "Open" ? -1 : 1));
  const goalsList = state.goals.filter((g) => g.studentId === s.id);

  const patch = (fields) => update((st) => ({
    ...st,
    students: st.students.map((x) => (x.id === s.id ? { ...x, ...fields } : x)),
  }));

  const toggleFollowup = (id) => update((st) => ({
    ...st,
    followups: st.followups.map((f) => (f.id === id ? { ...f, status: f.status === "Done" ? "Open" : "Done" } : f)),
  }));

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 40 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 6 }}>
        <PhotoPicker student={s} onChange={(photo) => patch({ photo })} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <div className="dos-display" style={{ fontSize: 21, fontWeight: 700 }}>{s.name}</div>
            {s.shana && <Chip tone="brass">Shana {s.shana}</Chip>}
          </div>
          {s.hebrewName && <div style={{ fontSize: 13.5, color: T.inkSoft }}>{s.hebrewName}</div>}
          <div style={{ fontSize: 12.5, color: T.inkFaint, marginTop: 2 }}>
            {shiur ? `${shiur.name}${shiur.rebbe ? " · " + shiur.rebbe : ""}` : "No Shiur assigned"}
          </div>
        </div>
        <button
          onClick={() => setShowEdit(true)}
          className="dos-btn"
          aria-label="Edit student"
          style={{ background: T.surfaceAlt, border: `1px solid ${T.border}`, borderRadius: 999, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}
        >
          <Pencil size={14} color={T.inkSoft} />
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, margin: "14px 0" }}>
        {s.whatsapp && (
          <a
            href={`https://wa.me/${s.whatsapp.replace(/\D/g, "")}`}
            target="_blank"
            rel="noreferrer"
            className="dos-btn"
            style={{ flex: 1, textDecoration: "none", background: T.sageBg, color: T.sage, borderRadius: 10, padding: "9px 10px", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontWeight: 700, fontSize: 13 }}
          >
            <Phone size={14} /> WhatsApp
          </a>
        )}
        <button
          onClick={() => (s.needsAttention ? patch({ needsAttention: false, attentionCategory: "" }) : setShowFlag(true))}
          className="dos-btn"
          style={{
            flex: 1,
            background: s.needsAttention ? T.brick : T.surface,
            color: s.needsAttention ? T.surface : T.brick,
            border: `1px solid ${T.brick}`,
            borderRadius: 10,
            padding: "9px 10px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            fontWeight: 700,
            fontSize: 13,
            cursor: "pointer",
          }}
        >
          <Flag size={14} /> {s.needsAttention ? (s.attentionCategory ? `Flagged · ${s.attentionCategory}` : "Flagged") : "Flag for Attention"}
        </button>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 14, borderBottom: `1px solid ${T.borderSoft}`, overflowX: "auto" }}>
        {[
          ["overview", "Overview"],
          ["interview", "Interview"],
          ["timeline", "Timeline"],
          ["goals", `Goals${goalsList.length ? ` (${goalsList.length})` : ""}`],
          ["followups", `Follow-ups${fups.filter(f=>f.status!=="Done").length ? ` (${fups.filter(f=>f.status!=="Done").length})` : ""}`],
        ].map(([k, label]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className="dos-btn"
            style={{
              background: "none",
              border: "none",
              borderBottom: `2px solid ${tab === k ? T.brass : "transparent"}`,
              color: tab === k ? T.ink : T.inkFaint,
              fontWeight: 700,
              fontSize: 13,
              padding: "8px 6px",
              cursor: "pointer",
              whiteSpace: "nowrap",
              flexShrink: 0,
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <>
          <Section title="How's he doing?">
            <EditableText value={s.howsDoing} onSave={(v) => patch({ howsDoing: v })} placeholder="Tap to add a current picture..." />
          </Section>
          <Section title="Strengths">
            <EditableText value={s.strengths} onSave={(v) => patch({ strengths: v })} placeholder="Tap to add..." minHeight={50} />
          </Section>
          <Section title="What's getting in the way">
            <EditableText value={s.obstacles} onSave={(v) => patch({ obstacles: v })} placeholder="Tap to add..." minHeight={50} />
          </Section>
          <Section title="What he needs from us">
            <EditableText value={s.needs} onSave={(v) => patch({ needs: v })} placeholder="Tap to add..." minHeight={50} />
          </Section>
          <Section title="Attendance (30 days)">
            {pct === null ? <EmptyState label="No attendance recorded yet" /> : (
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div className="dos-display" style={{ fontSize: 30, fontWeight: 700, color: pct < 80 ? T.brick : T.sage }}>{pct}%</div>
                <div style={{ flex: 1, height: 8, background: T.borderSoft, borderRadius: 4, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: pct < 80 ? T.brick : T.sage }} />
                </div>
              </div>
            )}
          </Section>
          <Section title="Family / Parent Contact">
            <EditableText value={s.parentContact} onSave={(v) => patch({ parentContact: v })} placeholder="Tap to add parent contact info..." minHeight={40} />
          </Section>
        </>
      )}

      {tab === "interview" && <InterviewTab student={s} patch={patch} />}

      {tab === "timeline" && (
        <>
          <PrimaryButton onClick={() => goto("addObservation", s.id)} full icon={Plus} tone="brass">Add Observation</PrimaryButton>
          <div style={{ height: 14 }} />
          {obs.length === 0 ? <EmptyState label="No observations yet" /> : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {obs.map((o) => (
                <div key={o.id} style={{ background: T.surface, border: `1px solid ${T.borderSoft}`, borderRadius: 12, padding: 13 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <Chip tone="brass">{o.area}</Chip>
                    <span style={{ fontSize: 11.5, color: T.inkFaint }}>{fmtDate(o.date)}</span>
                  </div>
                  <div style={{ fontSize: 14, lineHeight: 1.5 }}>{o.text}</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
                    {o.followUp ? <Chip tone="brick">Needs follow-up</Chip> : <span />}
                    {o.enteredBy && <span style={{ fontSize: 11, color: T.inkFaint }}>— {o.enteredBy}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {tab === "goals" && (
        <GoalsTab studentId={s.id} state={state} update={update} />
      )}

      {tab === "followups" && (
        <FollowupsTab studentId={s.id} state={state} update={update} />
      )}

      {showEdit && <EditStudentModal state={state} update={update} student={s} onClose={() => setShowEdit(false)} onDeleted={() => goto("students")} />}
      {showFlag && (
        <FlagAttentionModal
          current={s.attentionCategory}
          onSave={(cat) => { patch({ needsAttention: true, attentionCategory: cat }); setShowFlag(false); }}
          onClose={() => setShowFlag(false)}
        />
      )}
    </div>
  );
}

// Fast, always-editable field for use during a live conversation — no
// separate tap-to-edit step, just type and it saves when you move on.
function QuickField({ label, value, onSave, minHeight = 60, placeholder }) {
  const [val, setVal] = useState(value || "");
  useEffect(() => setVal(value || ""), [value]);
  return (
    <Field label={label}>
      <textarea
        style={{ ...inputStyle, minHeight, resize: "vertical" }}
        value={val}
        placeholder={placeholder}
        onChange={(e) => setVal(e.target.value)}
        onBlur={() => { if (val !== (value || "")) onSave(val); }}
      />
    </Field>
  );
}

function InterviewTab({ student, patch }) {
  return (
    <Section title="Interview / Check-in" icon={MessageSquarePlus}>
      <div style={{ fontSize: 12, color: T.inkFaint, marginBottom: 14, lineHeight: 1.5 }}>
        Fill this in while you're talking with {student.name.split(" ")[0]} — everything here saves as you go.
      </div>
      <Field label="Therapy status">
        <select
          style={inputStyle}
          value={student.therapyStatus || ""}
          onChange={(e) => patch({ therapyStatus: e.target.value })}
        >
          <option value="">— Not set —</option>
          {THERAPY_STATUS_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      </Field>
      <QuickField label="Background" value={student.background} onSave={(v) => patch({ background: v })} placeholder="Family, prior schools, anything relevant..." />
      <QuickField label="How's he doing?" value={student.howsDoing} onSave={(v) => patch({ howsDoing: v })} placeholder="Current picture..." />
      <QuickField label="Strengths" value={student.strengths} onSave={(v) => patch({ strengths: v })} placeholder="What he's good at, what lights him up..." />
      <QuickField label="What's getting in the way" value={student.obstacles} onSave={(v) => patch({ obstacles: v })} placeholder="Obstacles, struggles..." />
      <QuickField label="What he needs from us" value={student.needs} onSave={(v) => patch({ needs: v })} placeholder="Support, follow-up, next steps..." />
    </Section>
  );
}

function FlagAttentionModal({ current, onSave, onClose }) {
  const [cat, setCat] = useState(current || ATTENTION_CATEGORIES[0]);
  return (
    <ModalShell title="Flag for Attention" onClose={onClose}>
      <Field label="What's the concern?">
        <select style={inputStyle} value={cat} onChange={(e) => setCat(e.target.value)}>
          {ATTENTION_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </Field>
      <PrimaryButton tone="brick" onClick={() => onSave(cat)} full icon={Flag}>Flag Student</PrimaryButton>
    </ModalShell>
  );
}

function EditStudentModal({ state, update, student, onClose, onDeleted }) {
  const [name, setName] = useState(student.name);
  const [hebrewName, setHebrewName] = useState(student.hebrewName || "");
  const [whatsapp, setWhatsapp] = useState(student.whatsapp || "");
  const [shiurId, setShiurId] = useState(student.shiurId || "");
  const [shana, setShana] = useState(student.shana || "");
  const [background, setBackground] = useState(student.background || "");
  const [morningSeder2Rebbe, setMorningSeder2Rebbe] = useState(student.morningSeder2Rebbe || "");
  const [afternoonSeder1Rebbe, setAfternoonSeder1Rebbe] = useState(student.afternoonSeder1Rebbe || "");
  const [afternoonSeder2Rebbe, setAfternoonSeder2Rebbe] = useState(student.afternoonSeder2Rebbe || "");
  const [nightSederRebbe, setNightSederRebbe] = useState(student.nightSederRebbe || "");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const save = () => {
    if (!name.trim()) return;
    update((s) => ({
      ...s,
      students: s.students.map((x) => (x.id === student.id ? {
        ...x, name: name.trim(), hebrewName: hebrewName.trim(), whatsapp: whatsapp.trim(), shiurId, shana,
        background: background.trim(), morningSeder2Rebbe: morningSeder2Rebbe.trim(),
        afternoonSeder1Rebbe: afternoonSeder1Rebbe.trim(), afternoonSeder2Rebbe: afternoonSeder2Rebbe.trim(),
        nightSederRebbe: nightSederRebbe.trim(),
      } : x)),
    }));
    onClose();
  };

  const del = () => {
    update((s) => ({
      ...s,
      students: s.students.filter((x) => x.id !== student.id),
      attendance: s.attendance.map((a) => ({ ...a, absentIds: a.absentIds.filter((id) => id !== student.id) })),
      observations: s.observations.filter((o) => o.studentId !== student.id),
      followups: s.followups.filter((f) => f.studentId !== student.id),
      goals: s.goals.filter((g) => g.studentId !== student.id),
    }));
    onClose();
    onDeleted?.();
  };

  return (
    <ModalShell title="Edit Student" onClose={onClose}>
      <Field label="Full name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Hebrew name"><input style={inputStyle} value={hebrewName} onChange={(e) => setHebrewName(e.target.value)} /></Field>
      <Field label="WhatsApp / Cell"><input style={inputStyle} value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} /></Field>
      <Field label="Shana">
        <select style={inputStyle} value={shana} onChange={(e) => setShana(e.target.value)}>
          <option value="">— Not set —</option>
          {SHANA_OPTIONS.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </Field>
      <Field label="Primary Shiur (Morning Seder 1)">
        <select style={inputStyle} value={shiurId} onChange={(e) => setShiurId(e.target.value)}>
          <option value="">— None —</option>
          {state.shiurim.map((sh) => <option key={sh.id} value={sh.id}>{sh.name}</option>)}
        </select>
      </Field>
      <Field label="Background"><textarea style={{ ...inputStyle, minHeight: 60 }} value={background} onChange={(e) => setBackground(e.target.value)} /></Field>
      <Field label="Second Morning Rebbe"><input style={inputStyle} value={morningSeder2Rebbe} onChange={(e) => setMorningSeder2Rebbe(e.target.value)} /></Field>
      <Field label="First Afternoon Rebbe"><input style={inputStyle} value={afternoonSeder1Rebbe} onChange={(e) => setAfternoonSeder1Rebbe(e.target.value)} /></Field>
      <Field label="Second Afternoon Rebbe"><input style={inputStyle} value={afternoonSeder2Rebbe} onChange={(e) => setAfternoonSeder2Rebbe(e.target.value)} /></Field>
      <Field label="Night Seder Rebbe"><input style={inputStyle} value={nightSederRebbe} onChange={(e) => setNightSederRebbe(e.target.value)} /></Field>

      <PrimaryButton onClick={save} full disabled={!name.trim()}>Save Changes</PrimaryButton>

      <div style={{ marginTop: 18, paddingTop: 14, borderTop: `1px dashed ${T.border}` }}>
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="dos-btn" style={{ background: "none", border: "none", color: T.brick, fontSize: 12.5, fontWeight: 700, cursor: "pointer", textDecoration: "underline" }}>
            Delete this student
          </button>
        ) : (
          <div>
            <div style={{ fontSize: 12.5, color: T.brick, fontWeight: 700, marginBottom: 8 }}>
              Deletes {student.name} and all their attendance, observations, follow-ups, and goals. Permanent.
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <PrimaryButton tone="brick" onClick={del} full>Yes, Delete</PrimaryButton>
              <PrimaryButton tone="ghost" onClick={() => setConfirmDelete(false)} full>Cancel</PrimaryButton>
            </div>
          </div>
        )}
      </div>
    </ModalShell>
  );
}

const GOAL_STATUSES = ["Not Started", "In Progress", "Achieved", "On Hold"];

function GoalsTab({ studentId, state, update }) {
  const [showForm, setShowForm] = useState(false);
  const goalsList = state.goals.filter((g) => g.studentId === studentId).sort((a, b) => (a.dateCreated < b.dateCreated ? 1 : -1));

  const addGoal = (goal) => {
    update((s) => ({ ...s, goals: [...s.goals, { id: uid(), studentId, dateCreated: todayISO(), ...goal }] }));
    setShowForm(false);
  };
  const patchGoal = (id, fields) => update((s) => ({ ...s, goals: s.goals.map((g) => (g.id === id ? { ...g, ...fields } : g)) }));
  const delGoal = (id) => update((s) => ({ ...s, goals: s.goals.filter((g) => g.id !== id) }));

  return (
    <>
      {!showForm ? (
        <PrimaryButton onClick={() => setShowForm(true)} full icon={Plus} tone="brass">Add Goal</PrimaryButton>
      ) : (
        <GoalForm onSave={addGoal} onCancel={() => setShowForm(false)} />
      )}
      <div style={{ height: 14 }} />
      {goalsList.length === 0 ? <EmptyState label="No goals set yet" /> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {goalsList.map((g) => (
            <GoalCard key={g.id} goal={g} onPatch={(fields) => patchGoal(g.id, fields)} onDelete={() => delGoal(g.id)} />
          ))}
        </div>
      )}
    </>
  );
}

function GoalForm({ initial, onSave, onCancel }) {
  const [goal, setGoal] = useState(initial?.goal || "");
  const [responsible, setResponsible] = useState(initial?.responsible || "");
  const [status, setStatus] = useState(initial?.status || GOAL_STATUSES[0]);
  const [nextStep, setNextStep] = useState(initial?.nextStep || "");
  const [notes, setNotes] = useState(initial?.notes || "");

  return (
    <Section title={initial ? "Edit Goal" : "New Goal"} icon={Plus}>
      <Field label="Goal"><input style={inputStyle} value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="e.g. Improve consistency in Morning Seder" /></Field>
      <Field label="Responsible person"><input style={inputStyle} value={responsible} onChange={(e) => setResponsible(e.target.value)} placeholder="e.g. Rabbi Cohen" /></Field>
      <Field label="Status">
        <select style={inputStyle} value={status} onChange={(e) => setStatus(e.target.value)}>
          {GOAL_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="Next step"><input style={inputStyle} value={nextStep} onChange={(e) => setNextStep(e.target.value)} /></Field>
      <Field label="Notes"><textarea style={{ ...inputStyle, minHeight: 60 }} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      <div style={{ display: "flex", gap: 8 }}>
        <PrimaryButton onClick={() => onSave({ goal: goal.trim(), responsible: responsible.trim(), status, nextStep: nextStep.trim(), notes: notes.trim(), dateReviewed: todayISO() })} full disabled={!goal.trim()}>Save</PrimaryButton>
        <PrimaryButton tone="ghost" onClick={onCancel} full>Cancel</PrimaryButton>
      </div>
    </Section>
  );
}

function GoalCard({ goal, onPatch, onDelete }) {
  const [editing, setEditing] = useState(false);
  const statusTone = goal.status === "Achieved" ? "sage" : goal.status === "On Hold" ? "neutral" : "brass";

  if (editing) {
    return <GoalForm initial={goal} onSave={(fields) => { onPatch(fields); setEditing(false); }} onCancel={() => setEditing(false)} />;
  }

  return (
    <div style={{ background: T.surface, border: `1px solid ${T.borderSoft}`, borderRadius: 12, padding: 13 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6, gap: 8 }}>
        <div style={{ fontWeight: 700, fontSize: 14, flex: 1 }}>{goal.goal}</div>
        <Chip tone={statusTone}>{goal.status}</Chip>
      </div>
      {goal.responsible && <div style={{ fontSize: 12, color: T.inkFaint, marginBottom: 4 }}>Responsible: {goal.responsible}</div>}
      {goal.nextStep && <div style={{ fontSize: 13, marginBottom: 4 }}><strong>Next step:</strong> {goal.nextStep}</div>}
      {goal.notes && <div style={{ fontSize: 13, color: T.inkSoft, marginBottom: 4 }}>{goal.notes}</div>}
      <div style={{ fontSize: 11, color: T.inkFaint, marginTop: 6 }}>Created {fmtDate(goal.dateCreated)}{goal.dateReviewed ? ` · reviewed ${fmtDate(goal.dateReviewed)}` : ""}</div>
      <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
        <button onClick={() => setEditing(true)} className="dos-btn" style={{ background: "none", border: "none", color: T.brassDark, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>Edit</button>
        <button onClick={onDelete} className="dos-btn" style={{ background: "none", border: "none", color: T.brick, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>Delete</button>
      </div>
    </div>
  );
}

function FollowupsTab({ studentId, state, update }) {
  const [task, setTask] = useState("");
  const [due, setDue] = useState("");
  const fups = state.followups.filter((f) => f.studentId === studentId).sort((a, b) => (a.status === b.status ? 0 : a.status === "Open" ? -1 : 1));

  const add = () => {
    if (!task.trim()) return;
    update((s) => ({ ...s, followups: [...s.followups, { id: uid(), studentId, task: task.trim(), due, status: "Open", createdDate: todayISO() }] }));
    setTask(""); setDue("");
  };
  const toggle = (id) => update((s) => ({ ...s, followups: s.followups.map((f) => (f.id === id ? { ...f, status: f.status === "Done" ? "Open" : "Done" } : f)) }));
  const del = (id) => update((s) => ({ ...s, followups: s.followups.filter((f) => f.id !== id) }));

  return (
    <>
      <Section title="New Follow-up" icon={Plus}>
        <Field label="Task">
          <input style={inputStyle} value={task} onChange={(e) => setTask(e.target.value)} placeholder="e.g. Check in about learning" />
        </Field>
        <Field label="Due date (optional)">
          <input type="date" style={inputStyle} value={due} onChange={(e) => setDue(e.target.value)} />
        </Field>
        <PrimaryButton onClick={add} full disabled={!task.trim()}>Add Follow-up</PrimaryButton>
      </Section>
      {fups.length === 0 ? <EmptyState label="No follow-ups yet" /> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {fups.map((f) => {
            const overdue = f.status !== "Done" && f.due && f.due < todayISO();
            return (
              <div key={f.id} style={{ background: T.surface, border: `1px solid ${overdue ? T.brick + "66" : T.borderSoft}`, borderRadius: 12, padding: 12, display: "flex", alignItems: "flex-start", gap: 10 }}>
                <button onClick={() => toggle(f.id)} className="dos-btn" style={{ background: "none", border: "none", cursor: "pointer", padding: 0, marginTop: 1 }}>
                  {f.status === "Done" ? <CheckCircle2 size={20} color={T.sage} /> : <Circle size={20} color={T.inkFaint} />}
                </button>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, textDecoration: f.status === "Done" ? "line-through" : "none", color: f.status === "Done" ? T.inkFaint : T.ink }}>{f.task}</div>
                  {f.due && <div style={{ fontSize: 11.5, color: overdue ? T.brick : T.inkFaint, marginTop: 2, fontWeight: overdue ? 700 : 400 }}>{overdue ? "Overdue — " : "Due "}{fmtDate(f.due)}</div>}
                </div>
                <button onClick={() => del(f.id)} className="dos-btn" style={{ background: "none", border: "none", cursor: "pointer", color: T.inkFaint, padding: 4 }}>
                  <Trash2 size={15} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  DASHBOARD (admin / setup)                                          */
/* ------------------------------------------------------------------ */
function DashboardView({ state, update, goto }) {
  const attn = needsAttentionList(state);
  const overdue = state.followups.filter((f) => f.status !== "Done" && f.due && f.due < todayISO());
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [showAddShiur, setShowAddShiur] = useState(false);
  const [showManageShiurim, setShowManageShiurim] = useState(false);
  const [showPrintSheet, setShowPrintSheet] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [showRestore, setShowRestore] = useState(false);
  const [loadedPreset, setLoadedPreset] = useState(false);
  const [showAllFollowups, setShowAllFollowups] = useState(false);
  const [showAttendanceHistory, setShowAttendanceHistory] = useState(false);
  const [showEvaluation, setShowEvaluation] = useState(false);

  const loadPreloadedStudents = () => {
    update((s) => {
      const existingNames = new Set(s.students.map((x) => x.name.toLowerCase()));
      const toAdd = PRELOADED_STUDENTS.filter((p) => !existingNames.has(p.name.toLowerCase()));
      const newStudents = toAdd.map((p) => ({
        id: uid(), name: p.name, hebrewName: p.hebrewName, whatsapp: p.whatsapp,
        shiurId: "", shana: "", parentContact: p.parentContact,
        howsDoing: "", strengths: "", obstacles: "", needs: "", background: "", therapyStatus: "",
        needsAttention: false, attentionCategory: "",
      }));
      return { ...s, students: [...s.students, ...newStudents] };
    });
    setLoadedPreset(true);
  };

  const downloadBackup = () => {
    const payload = JSON.stringify(state, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `derech-backup-${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="dos-fade-in" style={{ padding: 16, paddingBottom: 40 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
        <StatCard label="Talmidim" value={state.students.length} icon={Users} />
        <StatCard label="Shiurim" value={state.shiurim.length} icon={BookOpen} />
        <StatCard label="Need Attention" value={attn.length} icon={AlertTriangle} tone="brick" />
        <StatCard label="Overdue Follow-ups" value={overdue.length} icon={Clock} tone="brick" />
      </div>

      <Section title="Students Needing Attention" icon={AlertTriangle}>
        {attn.length === 0 ? <EmptyState label="Nobody flagged right now" sub="Great sign." /> : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {attn.map((s) => {
              const pct = studentAttendancePct(state, s.id, 30);
              const ds = daysSince(lastObservationDate(state, s.id));
              return (
                <button key={s.id} onClick={() => goto("studentProfile", s.id)} className="dos-btn" style={{ display: "flex", alignItems: "center", gap: 10, background: T.brickBg, border: "none", borderRadius: 10, padding: "9px 11px", textAlign: "left", cursor: "pointer" }}>
                  <Avatar name={s.name} size={32} photo={s.photo} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5 }}>{s.name}</div>
                    <div style={{ fontSize: 11.5, color: T.brick }}>
                      {s.needsAttention ? "Flagged" : ""}{s.needsAttention && (pct !== null && pct < 80 || ds === null || ds > 14) ? " · " : ""}
                      {pct !== null && pct < 80 ? `${pct}% attendance` : ""}
                      {pct !== null && pct < 80 && (ds === null || ds > 14) ? " · " : ""}
                      {ds === null ? "no observations" : ds > 14 ? `${ds}d since last note` : ""}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </Section>

      <Section title="Attendance by Shiur" icon={ClipboardCheck}>
        {state.shiurim.length === 0 ? <EmptyState label="No Shiurim yet" /> : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {state.shiurim.map((sh) => {
              const pct = shiurAttendancePct(state, sh.id);
              return (
                <div key={sh.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                    <span style={{ fontWeight: 600 }}>{sh.name}</span>
                    <span style={{ color: T.inkSoft }}>{pct === null ? "no data" : `${pct}%`}</span>
                  </div>
                  <div style={{ height: 6, background: T.borderSoft, borderRadius: 3, overflow: "hidden" }}>
                    <div style={{ width: `${pct || 0}%`, height: "100%", background: pct !== null && pct < 80 ? T.brick : T.sage }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Section>

      <Section
        title="All Follow-ups"
        icon={Clock}
        action={
          <button onClick={() => setShowAllFollowups((v) => !v)} className="dos-btn" style={{ background: "none", border: "none", color: T.brassDark, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            {showAllFollowups ? "Hide" : `Show (${state.followups.filter((f) => f.status !== "Done").length})`}
          </button>
        }
      >
        {showAllFollowups && <AllFollowupsList state={state} update={update} goto={goto} />}
        {!showAllFollowups && <div style={{ fontSize: 12.5, color: T.inkFaint }}>Every open follow-up across all talmidim, in one place.</div>}
      </Section>

      <Section
        title="Attendance History"
        icon={ClipboardCheck}
        action={
          <button onClick={() => setShowAttendanceHistory((v) => !v)} className="dos-btn" style={{ background: "none", border: "none", color: T.brassDark, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            {showAttendanceHistory ? "Hide" : `Show (${state.attendance.length})`}
          </button>
        }
      >
        {showAttendanceHistory && <AttendanceHistoryList state={state} update={update} />}
        {!showAttendanceHistory && <div style={{ fontSize: 12.5, color: T.inkFaint }}>Browse past sessions and fix mistakes.</div>}
      </Section>

      <WeeklyReportSection state={state} />

      <Section title="Yeshiva Evaluation Report" icon={ShieldAlert}>
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
          A full evaluation of every talmid across the whole yeshiva, ranked by priority and highlighted for whoever needs attention — printable or exportable as a spreadsheet.
        </div>
        <PrimaryButton tone="brass" icon={FileText} full onClick={() => setShowEvaluation(true)}>Generate Evaluation Report</PrimaryButton>
      </Section>

      <Section title="Export Data" icon={Download}>
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
          Download any table as a spreadsheet file you can open in Excel or Google Sheets.
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <PrimaryButton tone="ghost" icon={Download} full onClick={() => downloadCSV(`talmidim-${todayISO()}.csv`, state.students.map((s) => ({
            Name: s.name, "Hebrew Name": s.hebrewName || "", Shana: s.shana || "", Shiur: state.shiurim.find((sh) => sh.id === s.shiurId)?.name || "",
            WhatsApp: s.whatsapp || "", "Attendance % (30d)": studentAttendancePct(state, s.id, 30) ?? "",
            "Needs Attention": s.needsAttention ? "Yes" : "No", "Therapy Status": s.therapyStatus || "", "Parent Contact": s.parentContact || "",
          })))}>Export Talmidim</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Download} full onClick={() => downloadCSV(`attendance-${todayISO()}.csv`, state.attendance.map((a) => ({
            Date: a.date, Shiur: state.shiurim.find((sh) => sh.id === a.shiurId)?.name || "", Seder: a.seder,
            "Absent Count": a.absentIds.length,
            "Absent Students": a.absentIds.map((id) => state.students.find((s) => s.id === id)?.name).filter(Boolean).join("; "),
            "Late Count": (a.lateIds || []).length,
            "Late Students": (a.lateIds || []).map((id) => state.students.find((s) => s.id === id)?.name).filter(Boolean).join("; "),
            "Recorded By": a.recordedBy || "", "Source": a.source || "manual",
          })))}>Export Attendance</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Download} full onClick={() => downloadCSV(`observations-${todayISO()}.csv`, state.observations.map((o) => ({
            Date: o.date, Student: state.students.find((s) => s.id === o.studentId)?.name || "", Area: o.area,
            Observation: o.text, "Needs Follow-Up": o.followUp ? "Yes" : "No",
          })))}>Export Observations</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Download} full onClick={() => downloadCSV(`followups-${todayISO()}.csv`, state.followups.map((f) => ({
            Student: state.students.find((s) => s.id === f.studentId)?.name || "", Task: f.task, Due: f.due || "", Status: f.status,
          })))}>Export Follow-ups</PrimaryButton>
        </div>
      </Section>

      <Section title="Set Up" icon={Settings}>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <PrimaryButton tone="ghost" icon={Plus} onClick={() => setShowAddShiur(true)} full>Add a Shiur</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Pencil} onClick={() => setShowManageShiurim(true)} full>Edit / Delete Shiurim</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Download} onClick={() => setShowPrintSheet(true)} full>Print Blank Attendance Sheet</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Plus} onClick={() => setShowAddStudent(true)} full>Add a Student</PrimaryButton>
          <PrimaryButton
            tone={loadedPreset ? "sage" : "brass"}
            icon={loadedPreset ? CheckCircle2 : Users}
            onClick={loadPreloadedStudents}
            full
          >
            {loadedPreset ? "Restored" : "Restore Starter Roster (if missing)"}
          </PrimaryButton>
          <PrimaryButton tone="ghost" icon={Upload} onClick={() => setShowImport(true)} full>Import Students from CSV</PrimaryButton>
        </div>
      </Section>

      <Section title="Backup & Safety" icon={Save}>
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
          There's no automatic history — download a backup regularly so you can always recover if something's deleted by mistake.
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <PrimaryButton tone="ghost" icon={Save} onClick={downloadBackup} full>Download Backup</PrimaryButton>
          <PrimaryButton tone="ghost" icon={Upload} onClick={() => setShowRestore(true)} full>Restore from Backup</PrimaryButton>
        </div>
      </Section>

      <AdvancedSection onReset={() => setShowReset(true)} />

      {showAddShiur && <AddShiurModal state={state} update={update} onClose={() => setShowAddShiur(false)} />}
      {showManageShiurim && <ManageShiurimModal state={state} update={update} onClose={() => setShowManageShiurim(false)} />}
      {showPrintSheet && <PrintSheetModal state={state} onClose={() => setShowPrintSheet(false)} />}
      {showEvaluation && <YeshivaEvaluationModal state={state} onClose={() => setShowEvaluation(false)} />}
      {showAddStudent && <AddStudentModal state={state} update={update} onClose={() => setShowAddStudent(false)} />}
      {showImport && <ImportModal state={state} update={update} onClose={() => setShowImport(false)} />}
      {showRestore && <RestoreModal update={update} onClose={() => setShowRestore(false)} />}
      {showReset && <ResetModal update={update} onClose={() => setShowReset(false)} />}
    </div>
  );
}

function WeeklyReportSection({ state }) {
  const [open, setOpen] = useState(false);
  const [reportText, setReportText] = useState("");
  const [copied, setCopied] = useState(false);

  const noAttendanceThisWeek = state.shiurim.filter((sh) => {
    const last = lastAttendanceDateForShiur(state, sh.id);
    return last === null || daysSince(last) > 7;
  });
  const noObservationsShiurim = state.shiurim.filter((sh) => shiurObservationCountRecent(state, sh.id, 14) === 0);
  const attn = needsAttentionList(state);

  const generate = () => {
    const lines = [];
    lines.push(`DERECH — Weekly Status Report`);
    lines.push(`Generated ${fmtDate(todayISO())}`);
    lines.push("");
    if (noAttendanceThisWeek.length > 0) {
      lines.push(`⚠ ATTENDANCE NOT LOGGED IN 7+ DAYS (${noAttendanceThisWeek.length})`);
      noAttendanceThisWeek.forEach((sh) => {
        const last = lastAttendanceDateForShiur(state, sh.id);
        lines.push(`- ${sh.name}${sh.rebbe ? " (" + sh.rebbe + ")" : ""}: ${last ? "last logged " + fmtDate(last) : "never logged"}`);
      });
      lines.push("");
    }
    if (noObservationsShiurim.length > 0) {
      lines.push(`⚠ NO OBSERVATIONS LOGGED IN 14+ DAYS (${noObservationsShiurim.length} Shiurim)`);
      noObservationsShiurim.forEach((sh) => lines.push(`- ${sh.name}${sh.rebbe ? " (" + sh.rebbe + ")" : ""}`));
      lines.push("");
    }
    if (attn.length > 0) {
      lines.push(`STUDENTS NEEDING ATTENTION (${attn.length})`);
      attn.forEach((s) => {
        const pct = studentAttendancePct(state, s.id, 30);
        const ds = daysSince(lastObservationDate(state, s.id));
        const reasons = [];
        if (s.needsAttention) reasons.push("flagged");
        if (pct !== null && pct < 80) reasons.push(`${pct}% attendance`);
        if (ds === null || ds > 14) reasons.push(ds === null ? "no observations yet" : `${ds}d since last note`);
        lines.push(`- ${s.name}: ${reasons.join(", ")}`);
      });
      lines.push("");
    }
    if (noAttendanceThisWeek.length === 0 && noObservationsShiurim.length === 0 && attn.length === 0) {
      lines.push("Nothing needs attention this week.");
    }
    setReportText(lines.join("\n"));
    setOpen(true);
    setCopied(false);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(reportText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard may be unavailable — text is still shown for manual copy
    }
  };

  return (
    <Section title="Weekly Report" icon={TrendingDown}>
      <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
        Generates a summary of attendance gaps, quiet Shiurim, and flagged students — copy it into a WhatsApp message or email whenever you want to send it out.
      </div>
      <PrimaryButton tone="brass" icon={ClipboardCheck} full onClick={generate}>Generate Report</PrimaryButton>
      {open && (
        <div style={{ marginTop: 12 }}>
          <textarea
            readOnly
            value={reportText}
            style={{ ...inputStyle, minHeight: 180, fontFamily: "monospace", fontSize: 12.5, whiteSpace: "pre-wrap" }}
          />
          <div style={{ marginTop: 8 }}>
            <PrimaryButton tone={copied ? "sage" : "ghost"} icon={copied ? CheckCircle2 : Copy} full onClick={copy}>
              {copied ? "Copied!" : "Copy to Clipboard"}
            </PrimaryButton>
          </div>
        </div>
      )}
    </Section>
  );
}

function YeshivaEvaluationModal({ state, onClose }) {
  const rows = state.students
    .map((s) => ({ student: s, risk: studentRiskInfo(state, s) }))
    .sort((a, b) => b.risk.score - a.risk.score || a.student.name.localeCompare(b.student.name));

  const high = rows.filter((r) => r.risk.level === "high");
  const watch = rows.filter((r) => r.risk.level === "watch");
  const ok = rows.filter((r) => r.risk.level === "ok");

  const overallPct = (() => {
    const pcts = state.students.map((s) => studentAttendancePct(state, s.id, 30)).filter((p) => p !== null);
    if (!pcts.length) return null;
    return Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length);
  })();

  const unassigned = state.students.filter((s) => !s.shiurId).length;

  const shiurRows = state.shiurim.map((sh) => {
    const roster = state.students.filter((s) => s.shiurId === sh.id);
    const pct = shiurAttendancePct(state, sh.id);
    const flagged = roster.filter((s) => studentRiskInfo(state, s).level !== "ok").length;
    return { shiur: sh, count: roster.length, pct, flagged };
  }).sort((a, b) => (a.pct ?? 999) - (b.pct ?? 999));

  const levelBg = (level) => (level === "high" ? T.brickBg : level === "watch" ? "#F6ECD2" : T.sageBg);
  const levelColor = (level) => (level === "high" ? T.brick : level === "watch" ? "#8A6B1E" : T.sage);
  const levelLabel = (level) => (level === "high" ? "High Priority" : level === "watch" ? "Watch" : "OK");

  const exportCSV = () => downloadCSV(`yeshiva-evaluation-${todayISO()}.csv`, rows.map(({ student: s, risk: r }) => ({
    Name: s.name, Shana: s.shana || "", Shiur: state.shiurim.find((sh) => sh.id === s.shiurId)?.name || "— None —",
    "Risk Level": levelLabel(r.level), "Attendance % (30d)": r.pct ?? "", "Days Since Observation": r.obsDays ?? "",
    "Open Follow-ups": r.openFups, "Therapy Status": s.therapyStatus || "", Reasons: r.reasons.join("; "),
  })));

  return (
    <ModalShell title="Yeshiva Evaluation Report" onClose={onClose}>
      <div className="dos-no-print">
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 12, lineHeight: 1.5 }}>
          A full snapshot of every talmid, ranked by who needs attention most. Print it, save it as a PDF, or export the underlying data as a CSV.
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 4 }}>
          <PrimaryButton onClick={() => window.print()} icon={FileText} full>Print / Save as PDF</PrimaryButton>
          <PrimaryButton tone="ghost" onClick={exportCSV} icon={Download} full>Export CSV</PrimaryButton>
        </div>
      </div>

      <div className="dos-print-area">
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 22, fontWeight: 700, marginBottom: 2 }}>Derech — Yeshiva Evaluation Report</div>
        <div style={{ fontSize: 12.5, color: "#666", marginBottom: 18 }}>Generated {fmtDate(todayISO())} · {state.students.length} talmidim</div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 22 }}>
          {[
            ["Total Talmidim", state.students.length],
            ["Avg Attendance (30d)", overallPct !== null ? `${overallPct}%` : "—"],
            ["High Priority", high.length],
            ["Watch", watch.length],
            ["No Shiur Assigned", unassigned],
          ].map(([label, val]) => (
            <div key={label} style={{ border: "1px solid #ccc", borderRadius: 8, padding: "10px 14px", minWidth: 110 }}>
              <div style={{ fontSize: 20, fontWeight: 700 }}>{val}</div>
              <div style={{ fontSize: 11, color: "#666" }}>{label}</div>
            </div>
          ))}
        </div>

        {shiurRows.length > 0 && (
          <>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 8 }}>By Shiur</div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, marginBottom: 22 }}>
              <thead>
                <tr>
                  {["Shiur", "Rebbe", "Talmidim", "Attendance %", "Need Attention"].map((h) => (
                    <th key={h} style={{ textAlign: "left", borderBottom: "2px solid #000", padding: "5px 6px" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {shiurRows.map(({ shiur, count, pct, flagged }) => (
                  <tr key={shiur.id}>
                    <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{shiur.name}</td>
                    <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{shiur.rebbe || "—"}</td>
                    <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{count}</td>
                    <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{pct !== null ? `${pct}%` : "—"}</td>
                    <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{flagged || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 8 }}>Every Talmid, Ranked by Priority</div>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr>
              {["Name", "Shana", "Shiur", "Status", "Attend %", "Last Obs.", "Follow-ups", "Why"].map((h) => (
                <th key={h} style={{ textAlign: "left", borderBottom: "2px solid #000", padding: "5px 6px" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(({ student: s, risk: r }) => (
              <tr key={s.id} style={{ background: r.level === "ok" ? "transparent" : levelBg(r.level) }}>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc", fontWeight: 600 }}>{s.name}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{s.shana || "—"}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{state.shiurim.find((sh) => sh.id === s.shiurId)?.name || "—"}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc", fontWeight: 700, color: levelColor(r.level) }}>{levelLabel(r.level)}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{r.pct !== null ? `${r.pct}%` : "—"}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{r.obsDays !== null ? `${r.obsDays}d ago` : "never"}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc" }}>{r.openFups || "—"}</td>
                <td style={{ padding: "5px 6px", borderBottom: "1px solid #ccc", fontSize: 11, color: "#555" }}>{r.reasons.join("; ") || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </ModalShell>
  );
}

function StatCard({ label, value, icon: Icon, tone = "ink" }) {
  const color = tone === "brick" ? T.brick : T.ink;
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.borderSoft}`, borderRadius: 13, padding: "13px 14px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, color: T.inkFaint }}>
        <Icon size={13} />
        <span style={{ fontSize: 11.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3 }}>{label}</span>
      </div>
      <div className="dos-display" style={{ fontSize: 26, fontWeight: 700, color }}>{value}</div>
    </div>
  );
}

function AdvancedSection({ onReset }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop: 22, marginBottom: 10 }}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="dos-btn"
        style={{
          background: "none",
          border: "none",
          color: T.inkFaint,
          fontSize: 12,
          fontWeight: 600,
          cursor: "pointer",
          padding: "4px 2px",
          textDecoration: "underline",
          textUnderlineOffset: 3,
        }}
      >
        {open ? "Hide advanced options" : "Advanced options"}
      </button>
      {open && (
        <div className="dos-fade-in" style={{ marginTop: 10, padding: 12, border: `1px dashed ${T.border}`, borderRadius: 10 }}>
          <div style={{ fontSize: 12, color: T.inkFaint, marginBottom: 8, lineHeight: 1.5 }}>
            Deletes everything for everyone using this tracker. Download a backup first.
          </div>
          <button
            onClick={onReset}
            className="dos-btn"
            style={{
              background: "none",
              border: `1px solid ${T.brick}88`,
              color: T.brick,
              borderRadius: 8,
              padding: "7px 12px",
              fontSize: 12.5,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Reset All Data
          </button>
        </div>
      )}
    </div>
  );
}

function ModalShell({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(38,54,74,0.45)", zIndex: 50, display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={onClose}>
      <div
        className="dos-fade-in dos-scrollbar"
        onClick={(e) => e.stopPropagation()}
        style={{ background: T.bg, width: "100%", maxWidth: 480, maxHeight: "85vh", overflowY: "auto", borderRadius: "18px 18px 0 0", padding: 18 }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div className="dos-display" style={{ fontSize: 17, fontWeight: 700 }}>{title}</div>
          <button onClick={onClose} className="dos-btn" style={{ background: T.surfaceAlt, border: "none", borderRadius: 999, width: 30, height: 30, cursor: "pointer" }}><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function PrintSheetModal({ state, onClose }) {
  const [shiurId, setShiurId] = useState(state.shiurim[0]?.id || "");
  const roster = state.students.filter((s) => s.shiurId === shiurId).sort((a, b) => a.name.localeCompare(b.name));
  const shiur = state.shiurim.find((sh) => sh.id === shiurId);

  return (
    <ModalShell title="Print Blank Attendance Sheet" onClose={onClose}>
      <div className="dos-no-print">
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 12, lineHeight: 1.5 }}>
          Prints a blank roster to hand out. Once it's filled in by hand, use "photograph a handwritten sheet" from Take Attendance to load it straight back into the app.
        </div>
        <Field label="Shiur">
          <select style={inputStyle} value={shiurId} onChange={(e) => setShiurId(e.target.value)}>
            {state.shiurim.map((sh) => <option key={sh.id} value={sh.id}>{sh.name}</option>)}
          </select>
        </Field>
        <PrimaryButton onClick={() => window.print()} full icon={Download} disabled={roster.length === 0}>
          Print / Save as PDF
        </PrimaryButton>
        {roster.length === 0 && <div style={{ fontSize: 12, color: T.brick, marginTop: 8 }}>No students in this Shiur yet.</div>}
      </div>

      <div className="dos-print-area">
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 20, fontWeight: 700, marginBottom: 4 }}>{shiur?.name || "Shiur"} — Attendance</div>
        <div style={{ display: "flex", gap: 24, fontSize: 13, marginBottom: 16 }}>
          <div>Seder: ________________________</div>
          <div>Date: ________________________</div>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", borderBottom: "2px solid #000", padding: "6px 4px" }}>Name</th>
              <th style={{ textAlign: "center", borderBottom: "2px solid #000", padding: "6px 4px", width: 60 }}>P</th>
              <th style={{ textAlign: "center", borderBottom: "2px solid #000", padding: "6px 4px", width: 60 }}>L</th>
              <th style={{ textAlign: "center", borderBottom: "2px solid #000", padding: "6px 4px", width: 60 }}>A</th>
            </tr>
          </thead>
          <tbody>
            {roster.map((s) => (
              <tr key={s.id}>
                <td style={{ padding: "8px 4px", borderBottom: "1px solid #999" }}>{s.name}</td>
                <td style={{ padding: "8px 4px", borderBottom: "1px solid #999", textAlign: "center" }}>☐</td>
                <td style={{ padding: "8px 4px", borderBottom: "1px solid #999", textAlign: "center" }}>☐</td>
                <td style={{ padding: "8px 4px", borderBottom: "1px solid #999", textAlign: "center" }}>☐</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </ModalShell>
  );
}

function AddShiurModal({ update, onClose }) {
  const [name, setName] = useState("");
  const [rebbe, setRebbe] = useState("");
  const save = () => {
    if (!name.trim()) return;
    update((s) => ({ ...s, shiurim: [...s.shiurim, { id: uid(), name: name.trim(), rebbe: rebbe.trim() }] }));
    onClose();
  };
  return (
    <ModalShell title="Add a Shiur" onClose={onClose}>
      <Field label="Shiur name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. First Morning" /></Field>
      <Field label="Rebbe"><input style={inputStyle} value={rebbe} onChange={(e) => setRebbe(e.target.value)} placeholder="e.g. Rabbi Cohen" /></Field>
      <PrimaryButton onClick={save} full disabled={!name.trim()}>Save Shiur</PrimaryButton>
    </ModalShell>
  );
}

function ManageShiurimModal({ state, update, onClose }) {
  const [editingId, setEditingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  return (
    <ModalShell title="Edit / Delete Shiurim" onClose={onClose}>
      {state.shiurim.length === 0 ? (
        <EmptyState label="No Shiurim yet" />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {state.shiurim.map((sh) => {
            const count = state.students.filter((s) => s.shiurId === sh.id).length;
            if (editingId === sh.id) {
              return <ShiurEditRow key={sh.id} shiur={sh} update={update} onDone={() => setEditingId(null)} />;
            }
            return (
              <div key={sh.id} style={{ border: `1px solid ${T.borderSoft}`, borderRadius: 10, padding: 11 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{sh.name}</div>
                    <div style={{ fontSize: 12, color: T.inkFaint }}>{sh.rebbe || "No Rebbe set"} · {count} student{count === 1 ? "" : "s"}</div>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button onClick={() => setEditingId(sh.id)} className="dos-btn" style={{ background: T.surfaceAlt, border: "none", borderRadius: 8, width: 30, height: 30, cursor: "pointer" }}>
                      <Pencil size={13} color={T.inkSoft} />
                    </button>
                    <button onClick={() => setConfirmDeleteId(sh.id)} className="dos-btn" style={{ background: T.brickBg, border: "none", borderRadius: 8, width: 30, height: 30, cursor: "pointer" }}>
                      <Trash2 size={13} color={T.brick} />
                    </button>
                  </div>
                </div>
                {confirmDeleteId === sh.id && (
                  <div style={{ marginTop: 10, background: T.brickBg, borderRadius: 8, padding: 10 }}>
                    <div style={{ fontSize: 12, color: T.brick, fontWeight: 700, marginBottom: 8 }}>
                      Delete this Shiur? {count > 0 ? `${count} student${count === 1 ? "" : "s"} will become unassigned.` : ""}
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <PrimaryButton
                        tone="brick"
                        full
                        onClick={() => {
                          update((s) => ({
                            ...s,
                            shiurim: s.shiurim.filter((x) => x.id !== sh.id),
                            students: s.students.map((x) => (x.shiurId === sh.id ? { ...x, shiurId: "" } : x)),
                          }));
                          setConfirmDeleteId(null);
                        }}
                      >
                        Delete
                      </PrimaryButton>
                      <PrimaryButton tone="ghost" full onClick={() => setConfirmDeleteId(null)}>Cancel</PrimaryButton>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </ModalShell>
  );
}

function ShiurEditRow({ shiur, update, onDone }) {
  const [name, setName] = useState(shiur.name);
  const [rebbe, setRebbe] = useState(shiur.rebbe || "");
  const save = () => {
    if (!name.trim()) return;
    update((s) => ({ ...s, shiurim: s.shiurim.map((x) => (x.id === shiur.id ? { ...x, name: name.trim(), rebbe: rebbe.trim() } : x)) }));
    onDone();
  };
  return (
    <div style={{ border: `1px solid ${T.brass}55`, borderRadius: 10, padding: 11 }}>
      <Field label="Shiur name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Rebbe"><input style={inputStyle} value={rebbe} onChange={(e) => setRebbe(e.target.value)} /></Field>
      <div style={{ display: "flex", gap: 8 }}>
        <PrimaryButton onClick={save} full disabled={!name.trim()}>Save</PrimaryButton>
        <PrimaryButton tone="ghost" onClick={onDone} full>Cancel</PrimaryButton>
      </div>
    </div>
  );
}

function AllFollowupsList({ state, update, goto }) {
  const items = [...state.followups].sort((a, b) => {
    if (a.status !== b.status) return a.status === "Done" ? 1 : -1;
    if (a.due && b.due) return a.due < b.due ? -1 : 1;
    return a.due ? -1 : b.due ? 1 : 0;
  });
  const toggle = (id) => update((s) => ({ ...s, followups: s.followups.map((f) => (f.id === id ? { ...f, status: f.status === "Done" ? "Open" : "Done" } : f)) }));

  if (items.length === 0) return <EmptyState label="No follow-ups yet" />;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {items.map((f) => {
        const student = state.students.find((s) => s.id === f.studentId);
        const overdue = f.status !== "Done" && f.due && f.due < todayISO();
        return (
          <div key={f.id} style={{ background: T.surfaceAlt, border: `1px solid ${overdue ? T.brick + "66" : T.borderSoft}`, borderRadius: 10, padding: 10, display: "flex", alignItems: "flex-start", gap: 9 }}>
            <button onClick={() => toggle(f.id)} className="dos-btn" style={{ background: "none", border: "none", cursor: "pointer", padding: 0, marginTop: 1 }}>
              {f.status === "Done" ? <CheckCircle2 size={18} color={T.sage} /> : <Circle size={18} color={T.inkFaint} />}
            </button>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, textDecoration: f.status === "Done" ? "line-through" : "none", color: f.status === "Done" ? T.inkFaint : T.ink }}>{f.task}</div>
              <button onClick={() => student && goto("studentProfile", student.id)} className="dos-btn" style={{ background: "none", border: "none", color: T.brassDark, fontSize: 11.5, fontWeight: 700, cursor: "pointer", padding: 0 }}>
                {student?.name || "Unknown student"}
              </button>
              {f.due && <div style={{ fontSize: 11, color: overdue ? T.brick : T.inkFaint, marginTop: 2, fontWeight: overdue ? 700 : 400 }}>{overdue ? "Overdue — " : "Due "}{fmtDate(f.due)}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function AttendanceHistoryList({ state, update }) {
  const [editingId, setEditingId] = useState(null);
  const sessions = [...state.attendance].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 60);

  if (sessions.length === 0) return <EmptyState label="No attendance recorded yet" />;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {sessions.map((a) => {
        const shiur = state.shiurim.find((sh) => sh.id === a.shiurId);
        if (editingId === a.id) {
          return <SessionEditRow key={a.id} session={a} state={state} update={update} onDone={() => setEditingId(null)} />;
        }
        return (
          <button
            key={a.id}
            onClick={() => setEditingId(a.id)}
            className="dos-btn"
            style={{ width: "100%", textAlign: "left", background: T.surfaceAlt, border: `1px solid ${T.borderSoft}`, borderRadius: 10, padding: 10, cursor: "pointer" }}
          >
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div style={{ fontWeight: 700, fontSize: 13 }}>{shiur?.name || "Unknown Shiur"} · {a.seder}</div>
              <span style={{ fontSize: 11.5, color: T.inkFaint }}>{fmtDate(a.date)}</span>
            </div>
            <div style={{ fontSize: 11.5, color: T.inkFaint, marginTop: 3 }}>
              {a.absentIds.length} absent{(a.lateIds || []).length ? ` · ${a.lateIds.length} late` : ""}{a.recordedBy ? ` · logged by ${a.recordedBy}` : ""}{a.source === "photo" ? " · from photo" : ""}
            </div>
          </button>
        );
      })}
    </div>
  );
}

function SessionEditRow({ session, state, update, onDone }) {
  const [absent, setAbsent] = useState(new Set(session.absentIds));
  const [late, setLate] = useState(new Set(session.lateIds || []));
  const [confirmDelete, setConfirmDelete] = useState(false);
  const roster = state.students.filter((s) => s.shiurId === session.shiurId);
  const shiur = state.shiurim.find((sh) => sh.id === session.shiurId);

  const setRowStatus = (id, st) => {
    setAbsent((prev) => { const next = new Set(prev); st === "absent" ? next.add(id) : next.delete(id); return next; });
    setLate((prev) => { const next = new Set(prev); st === "late" ? next.add(id) : next.delete(id); return next; });
  };

  const save = () => {
    update((s) => ({ ...s, attendance: s.attendance.map((a) => (a.id === session.id ? { ...a, absentIds: Array.from(absent), lateIds: Array.from(late) } : a)) }));
    onDone();
  };
  const del = () => {
    update((s) => ({ ...s, attendance: s.attendance.filter((a) => a.id !== session.id) }));
    onDone();
  };

  return (
    <div style={{ border: `1px solid ${T.brass}55`, borderRadius: 10, padding: 11 }}>
      <div style={{ fontWeight: 700, fontSize: 13.5, marginBottom: 8 }}>{shiur?.name} · {session.seder} · {fmtDate(session.date)}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 10, maxHeight: 220, overflowY: "auto" }} className="dos-scrollbar">
        {roster.map((s) => {
          const rowStatus = statusOf(s.id, absent, late);
          return (
            <div key={s.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: T.surface, borderRadius: 8, padding: "6px 9px" }}>
              <span style={{ fontSize: 13 }}>{s.name}</span>
              <StatusPicker status={rowStatus} onChange={(st) => setRowStatus(s.id, st)} size="small" />
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <PrimaryButton onClick={save} full icon={Save}>Save Changes</PrimaryButton>
        <PrimaryButton tone="ghost" onClick={onDone} full>Cancel</PrimaryButton>
      </div>
      {!confirmDelete ? (
        <button onClick={() => setConfirmDelete(true)} className="dos-btn" style={{ background: "none", border: "none", color: T.brick, fontSize: 12, fontWeight: 700, cursor: "pointer", textDecoration: "underline" }}>
          Delete this session
        </button>
      ) : (
        <div>
          <div style={{ fontSize: 12, color: T.brick, fontWeight: 700, marginBottom: 6 }}>Permanently delete this attendance record?</div>
          <div style={{ display: "flex", gap: 8 }}>
            <PrimaryButton tone="brick" full onClick={del}>Yes, Delete</PrimaryButton>
            <PrimaryButton tone="ghost" full onClick={() => setConfirmDelete(false)}>Cancel</PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
}

function AddStudentModal({ state, update, onClose }) {
  const [name, setName] = useState("");
  const [hebrewName, setHebrewName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [shiurId, setShiurId] = useState(state.shiurim[0]?.id || "");
  const [shana, setShana] = useState("");
  const save = () => {
    if (!name.trim()) return;
    update((s) => ({
      ...s,
      students: [...s.students, {
        id: uid(), name: name.trim(), hebrewName: hebrewName.trim(), whatsapp: whatsapp.trim(),
        shiurId, shana, parentContact: "", howsDoing: "", strengths: "", obstacles: "", needs: "",
        background: "", therapyStatus: "",
        needsAttention: false, attentionCategory: "",
      }],
    }));
    onClose();
  };
  return (
    <ModalShell title="Add a Student" onClose={onClose}>
      <Field label="Full name"><input style={inputStyle} autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Shmuel Cohen" /></Field>
      <Field label="Hebrew name (optional)"><input style={inputStyle} value={hebrewName} onChange={(e) => setHebrewName(e.target.value)} /></Field>
      <Field label="WhatsApp / Cell"><input style={inputStyle} value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} placeholder="e.g. 555-123-4567" /></Field>
      <Field label="Shana">
        <select style={inputStyle} value={shana} onChange={(e) => setShana(e.target.value)}>
          <option value="">— Not set —</option>
          {SHANA_OPTIONS.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </Field>
      <Field label="Primary Shiur">
        <select style={inputStyle} value={shiurId} onChange={(e) => setShiurId(e.target.value)}>
          <option value="">— None —</option>
          {state.shiurim.map((sh) => <option key={sh.id} value={sh.id}>{sh.name}</option>)}
        </select>
      </Field>
      <PrimaryButton onClick={save} full disabled={!name.trim()}>Save Student</PrimaryButton>
    </ModalShell>
  );
}

function ImportModal({ state, update, onClose }) {
  const [status, setStatus] = useState(null);
  const [fileName, setFileName] = useState(null);
  const fileRef = useRef();

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = results.data;
        update((s) => {
          const shiurim = [...s.shiurim];
          const findOrCreateShiur = (name, rebbe) => {
            if (!name) return "";
            let sh = shiurim.find((x) => x.name.toLowerCase() === name.toLowerCase());
            if (!sh) {
              sh = { id: uid(), name, rebbe: rebbe || "" };
              shiurim.push(sh);
            }
            return sh.id;
          };
          const newStudents = rows
            .map((r) => {
              const name = (r.Name || r.name || r["Full Name"] || "").trim();
              if (!name) return null;
              const shiurName = (r.Shiur || r.shiur || r["Primary Shiur"] || "").trim();
              const rebbeName = (r.Rebbe || r.rebbe || "").trim();
              return {
                id: uid(),
                name,
                hebrewName: (r["Hebrew Name"] || r.hebrewName || "").trim(),
                whatsapp: (r.WhatsApp || r.whatsapp || r.Phone || r.phone || "").trim(),
                shiurId: findOrCreateShiur(shiurName, rebbeName),
                shana: SHANA_OPTIONS.includes((r.Shana || r.shana || "").trim()) ? (r.Shana || r.shana).trim() : "",
                parentContact: (r["Parent Contact"] || "").trim(),
                howsDoing: "", strengths: "", obstacles: "", needs: "", background: "", therapyStatus: "",
                needsAttention: false, attentionCategory: "",
              };
            })
            .filter(Boolean);
          setStatus(`Imported ${newStudents.length} students${shiurim.length > s.shiurim.length ? ` and created ${shiurim.length - s.shiurim.length} new Shiurim` : ""}.`);
          return { ...s, students: [...s.students, ...newStudents], shiurim };
        });
      },
      error: (err) => setStatus("Error reading file: " + err.message),
    });
  };

  return (
    <ModalShell title="Import Students from CSV" onClose={onClose}>
      <div style={{ fontSize: 13, color: T.inkSoft, marginBottom: 14, lineHeight: 1.5 }}>
        Your CSV should have a <strong>Name</strong> column. Optional columns: <strong>Hebrew Name</strong>, <strong>WhatsApp</strong>, <strong>Shiur</strong>, <strong>Rebbe</strong>, <strong>Parent Contact</strong>. Shiurim mentioned that don't exist yet will be created automatically.
      </div>
      <button
        onClick={() => fileRef.current?.click()}
        className="dos-btn"
        style={{
          width: "100%",
          background: T.surface,
          border: `2px dashed ${T.border}`,
          borderRadius: 12,
          padding: "22px 16px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 8,
          cursor: "pointer",
          marginBottom: 12,
        }}
      >
        <Upload size={22} color={T.brassDark} />
        <span style={{ fontWeight: 700, fontSize: 14, color: T.ink }}>
          {fileName ? fileName : "Tap to choose a CSV file"}
        </span>
        <span style={{ fontSize: 11.5, color: T.inkFaint }}>
          {fileName ? "Tap again to pick a different file" : "From your Downloads or Files app"}
        </span>
      </button>
      <input ref={fileRef} type="file" accept=".csv" onChange={handleFile} style={{ display: "none" }} />
      {status && <div style={{ background: T.sageBg, color: T.sage, borderRadius: 8, padding: 10, fontSize: 13, fontWeight: 600, marginBottom: 12 }}>{status}</div>}
      <PrimaryButton onClick={onClose} full>Done</PrimaryButton>
    </ModalShell>
  );
}

function RestoreModal({ update, onClose }) {
  const [status, setStatus] = useState(null);
  const [pending, setPending] = useState(null);

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (!parsed || !Array.isArray(parsed.students)) throw new Error("not a valid backup file");
        setPending(parsed);
        setStatus(`Backup looks valid — ${parsed.students.length} students, ${parsed.shiurim?.length || 0} Shiurim. Confirm below to restore.`);
      } catch {
        setStatus("This doesn't look like a valid backup file.");
        setPending(null);
      }
    };
    reader.readAsText(file);
  };

  const restore = () => {
    if (!pending) return;
    update(() => ({ ...EMPTY_STATE, ...pending }));
    onClose();
  };

  return (
    <ModalShell title="Restore from Backup" onClose={onClose}>
      <div style={{ fontSize: 13, color: T.inkSoft, marginBottom: 12, lineHeight: 1.5 }}>
        Upload a backup file you downloaded earlier. This will <strong>replace all current data</strong> — for everyone using this tracker — with what's in the backup.
      </div>
      <input type="file" accept=".json" onChange={handleFile} style={{ marginBottom: 12 }} />
      {status && (
        <div style={{ background: pending ? T.sageBg : T.brickBg, color: pending ? T.sage : T.brick, borderRadius: 8, padding: 10, fontSize: 13, fontWeight: 600, marginBottom: 12 }}>
          {status}
        </div>
      )}
      {pending && <PrimaryButton tone="brick" onClick={restore} full>Restore This Backup</PrimaryButton>}
    </ModalShell>
  );
}

function ResetModal({ update, onClose }) {
  const [confirming, setConfirming] = useState(false);
  return (
    <ModalShell title="Reset All Data" onClose={onClose}>
      <div style={{ fontSize: 14, color: T.inkSoft, marginBottom: 16, lineHeight: 1.5 }}>
        This deletes every student, Shiur, attendance record, observation, and follow-up — for everyone using this tracker. This can't be undone.
      </div>
      {!confirming ? (
        <PrimaryButton tone="brick" onClick={() => setConfirming(true)} full>Reset Everything</PrimaryButton>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700, color: T.brick }}>Are you sure? This is permanent.</div>
          <PrimaryButton tone="brick" onClick={() => { update(() => ({ ...EMPTY_STATE })); onClose(); }} full>Yes, delete everything</PrimaryButton>
          <PrimaryButton tone="ghost" onClick={() => setConfirming(false)} full>Cancel</PrimaryButton>
        </div>
      )}
    </ModalShell>
  );
}

/* ------------------------------------------------------------------ */
/*  Bottom nav                                                          */
/* ------------------------------------------------------------------ */
function BottomNav({ current, goto }) {
  const items = [
    { key: "home", icon: BookOpen, label: "Home" },
    { key: "attendance", icon: ClipboardCheck, label: "Attendance" },
    { key: "students", icon: Users, label: "Talmidim" },
    { key: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
  ];
  const active = (k) => current === k || (k === "students" && current === "studentProfile") || (k === "attendance" && current === "addObservation");
  return (
    <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, height: 64, background: T.surface, borderTop: `1px solid ${T.borderSoft}`, display: "flex", zIndex: 30 }}>
      {items.map((it) => (
        <button
          key={it.key}
          onClick={() => goto(it.key)}
          className="dos-btn"
          style={{ flex: 1, background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3, color: active(it.key) ? T.brass : T.inkFaint }}
        >
          <it.icon size={20} strokeWidth={active(it.key) ? 2.4 : 2} />
          <span style={{ fontSize: 10.5, fontWeight: 700 }}>{it.label}</span>
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  APP ROOT — storage + routing                                       */
/* ------------------------------------------------------------------ */
export default function App() {
  const [state, setState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [syncStatus, setSyncStatus] = useState("saved"); // "saved" | "saving" | "offline" | "local-only"
  const [view, setView] = useState("home");
  const [param, setParam] = useState(null);
  const [history, setHistory] = useState([]);
  const [currentRebbe, setCurrentRebbeState] = useState(() => getConfig().rebbeName || "");
  const [showRebbeModal, setShowRebbeModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [config, setConfigState] = useState(getConfig());
  const saveTimer = useRef(null);
  const retryTimer = useRef(null);
  const pendingState = useRef(null);
  const retryDelay = useRef(4000);

  const setCurrentRebbe = (name) => {
    setCurrentRebbeState(name);
    const next = setConfig({ rebbeName: name });
    setConfigState(next);
  };

  const buildSeededState = () => {
    const seededStudents = PRELOADED_STUDENTS.map((p) => ({
      id: uid(), name: p.name, hebrewName: p.hebrewName, whatsapp: p.whatsapp,
      shiurId: "", parentContact: p.parentContact,
      howsDoing: "", strengths: "", obstacles: "", needs: "",
      needsAttention: false, attentionCategory: "",
    }));
    return { ...EMPTY_STATE, students: seededStudents };
  };

  // Every save writes to this device's local IndexedDB immediately (always succeeds, fully
  // offline-safe), then best-effort pushes to Supabase in the background if it's configured.
  const attemptSave = useCallback(async (toSave) => {
    await saveLocal(toSave);
    if (!isConfigured()) {
      setSyncStatus("local-only");
      pendingState.current = null;
      return;
    }
    setSyncStatus("saving");
    try {
      await pushRemote(toSave);
      if (pendingState.current === toSave) {
        pendingState.current = null;
        retryDelay.current = 4000;
        setSyncStatus("saved");
        if (retryTimer.current) { clearTimeout(retryTimer.current); retryTimer.current = null; }
      }
    } catch {
      setSyncStatus("offline");
      if (retryTimer.current) clearTimeout(retryTimer.current);
      retryTimer.current = setTimeout(() => {
        if (pendingState.current) attemptSave(pendingState.current);
      }, retryDelay.current);
      retryDelay.current = Math.min(retryDelay.current * 1.5, 30000);
    }
  }, []);

  useEffect(() => {
    const goOnline = () => { if (pendingState.current) attemptSave(pendingState.current); };
    window.addEventListener("online", goOnline);
    return () => window.removeEventListener("online", goOnline);
  }, [attemptSave]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      // 1. Always load the local copy first — instant, works with zero connectivity.
      const local = await loadLocal();
      if (local && mounted) {
        setState(local.data);
        setLoading(false);
      }

      // 2. In the background, check Supabase for a newer copy (e.g. another Rebbe's device
      //    synced changes while this device was offline). Never blocks the UI.
      if (isConfigured()) {
        try {
          const remote = await pullRemote();
          if (remote && mounted) {
            if (!local || remote.updatedAt > local.updatedAt) {
              setState(remote.data);
              await saveLocal(remote.data);
            }
            setSyncStatus("saved");
          }
        } catch {
          if (mounted) setSyncStatus(local ? "offline" : "offline");
        }
      }

      // 3. First time this device has ever opened the app with nothing local and nothing remote —
      //    seed the starting roster.
      if (!local) {
        let seeded = buildSeededState();
        if (isConfigured()) {
          try {
            const remote = await pullRemote();
            if (remote) seeded = remote.data;
          } catch {
            // offline on very first launch with no local copy — nothing to recover, seed fresh
          }
        }
        if (mounted) setState(seeded);
        await saveLocal(seeded);
        if (isConfigured()) attemptSave(seeded);
      }

      if (mounted) setLoading(false);
    })();
    return () => { mounted = false; };
  }, []);

  const update = useCallback((fn) => {
    setState((prev) => {
      const next = fn(prev);
      pendingState.current = next;
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => attemptSave(next), 500);
      return next;
    });
  }, [attemptSave]);

  const goto = (v, p = null) => {
    setHistory((h) => [...h, { view, param }]);
    setView(v);
    setParam(p);
  };
  const back = () => {
    setHistory((h) => {
      if (h.length === 0) { setView("home"); setParam(null); return h; }
      const prev = h[h.length - 1];
      setView(prev.view);
      setParam(prev.param);
      return h.slice(0, -1);
    });
  };

  if (loading || !state) {
    return (
      <div className="dos-root" style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <GlobalStyle />
        <Loader2 className="dos-btn" size={26} color={T.brass} style={{ animation: "spin 1s linear infinite" }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  const titles = {
    home: "Derech",
    attendance: "Take Attendance",
    addObservation: "Add Observation",
    students: "Talmidim",
    studentProfile: state.students.find((s) => s.id === param)?.name || "Talmid",
    dashboard: "Dashboard",
    photoAttendance: "Photo Attendance",
  };

  return (
    <div className="dos-root" style={{ minHeight: "100vh", maxWidth: 520, margin: "0 auto", position: "relative" }}>
      <GlobalStyle />
      <TopBar
        title={titles[view]}
        onBack={view === "home" ? null : back}
        right={
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            {syncStatus !== "saved" && (
              <span style={{ fontSize: 10.5, fontWeight: 700, color: syncStatus === "offline" ? "#F3D0C4" : "rgba(255,255,255,0.75)", display: "flex", alignItems: "center", gap: 4 }}>
                {syncStatus === "saving" && (<><Loader2 size={11} style={{ animation: "spin 1s linear infinite" }} /> Syncing</>)}
                {syncStatus === "offline" && (<><CloudOff size={11} /> Offline</>)}
                {syncStatus === "local-only" && (<><CloudOff size={11} /> This device only</>)}
              </span>
            )}
            <button
              onClick={() => setShowSettingsModal(true)}
              className="dos-btn"
              aria-label="Settings"
              style={{ background: "rgba(255,255,255,0.12)", border: "none", borderRadius: 999, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}
            >
              <Settings size={14} color={T.surface} />
            </button>
            <button
              onClick={() => setShowRebbeModal(true)}
              className="dos-btn"
              style={{
                background: "rgba(255,255,255,0.12)", border: "none", borderRadius: 999,
                padding: "5px 11px", color: T.surface, fontSize: 11.5, fontWeight: 700, cursor: "pointer",
                maxWidth: 100, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
              }}
            >
              {currentRebbe ? currentRebbe : "Set your name"}
            </button>
          </div>
        }
      />
      {syncStatus === "offline" && (
        <div style={{ background: T.brickBg, color: T.brick, fontSize: 12, fontWeight: 600, textAlign: "center", padding: "6px 12px" }}>
          No connection — your changes are saved on this device and will sync to other devices once you're back online.
        </div>
      )}
      <div className="dos-scrollbar" style={{ minHeight: "calc(100vh - 130px)" }}>
        {view === "home" && <HomeView state={state} goto={goto} />}
        {view === "attendance" && <AttendanceView state={state} update={update} goto={goto} recordedBy={currentRebbe} />}
        {view === "photoAttendance" && <PhotoAttendanceView state={state} update={update} goto={goto} recordedBy={currentRebbe} anthropicApiKey={config.anthropicApiKey} />}
        {view === "addObservation" && <AddObservationView state={state} update={update} goto={goto} presetStudentId={param} enteredBy={currentRebbe} />}
        {view === "students" && <StudentsListView state={state} goto={goto} update={update} />}
        {view === "studentProfile" && <StudentProfileView state={state} update={update} goto={goto} studentId={param} enteredBy={currentRebbe} />}
        {view === "dashboard" && <DashboardView state={state} update={update} goto={goto} />}
      </div>
      <BottomNav current={view} goto={(k) => { setHistory([]); setView(k); setParam(null); }} />
      {showRebbeModal && <RebbeIdentityModal current={currentRebbe} onSave={setCurrentRebbe} onClose={() => setShowRebbeModal(false)} />}
      {showSettingsModal && (
        <SettingsModal
          config={config}
          onSave={(next) => { const saved = setConfig(next); setConfigState(saved); }}
          syncStatus={syncStatus}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}

function RebbeIdentityModal({ current, onSave, onClose }) {
  const [val, setVal] = useState(current || "");
  return (
    <ModalShell title="Who's Recording?" onClose={onClose}>
      <div style={{ fontSize: 13, color: T.inkSoft, marginBottom: 14, lineHeight: 1.5 }}>
        Your name gets tagged on attendance and observations you add, so everyone can see who logged what. This isn't a login — it's just saved on this device, so if this is your own phone or tablet you only need to set it once.
      </div>
      <Field label="Your name">
        <input style={inputStyle} value={val} onChange={(e) => setVal(e.target.value)} placeholder="e.g. Rabbi Cohen" autoFocus />
      </Field>
      <PrimaryButton onClick={() => { onSave(val.trim()); onClose(); }} full>Save</PrimaryButton>
    </ModalShell>
  );
}

function SettingsModal({ config, onSave, syncStatus, onClose }) {
  const [supabaseUrl, setSupabaseUrl] = useState(config.supabaseUrl || "");
  const [supabaseAnonKey, setSupabaseAnonKey] = useState(config.supabaseAnonKey || "");
  const [anthropicApiKey, setAnthropicApiKey] = useState(config.anthropicApiKey || "");
  const [showKeys, setShowKeys] = useState(false);

  const save = () => {
    onSave({
      supabaseUrl: supabaseUrl.trim(),
      supabaseAnonKey: supabaseAnonKey.trim(),
      anthropicApiKey: anthropicApiKey.trim(),
    });
    onClose();
  };

  return (
    <ModalShell title="Settings" onClose={onClose}>
      <Section title="Sync Across Devices" icon={Cloud}>
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 12, lineHeight: 1.5 }}>
          This device works fully offline on its own. To share data with other Rebbeim's devices, connect a free Supabase project — see the setup guide for the exact steps and the one-time database command to run.
        </div>
        <Field label="Supabase Project URL">
          <input style={inputStyle} value={supabaseUrl} onChange={(e) => setSupabaseUrl(e.target.value)} placeholder="https://xxxxx.supabase.co" type={showKeys ? "text" : "password"} />
        </Field>
        <Field label="Supabase Anon Key">
          <input style={inputStyle} value={supabaseAnonKey} onChange={(e) => setSupabaseAnonKey(e.target.value)} placeholder="eyJhbGciOi..." type={showKeys ? "text" : "password"} />
        </Field>
      </Section>
      <Section title="Photo Attendance Reading" icon={Key}>
        <div style={{ fontSize: 12.5, color: T.inkSoft, marginBottom: 12, lineHeight: 1.5 }}>
          Optional — only needed to use "photograph a handwritten sheet." Uses your own Anthropic API key, stored only on this device. Anyone with access to this device's browser tools could see it, so only add a key you're comfortable having live on staff devices.
        </div>
        <Field label="Anthropic API Key">
          <input style={inputStyle} value={anthropicApiKey} onChange={(e) => setAnthropicApiKey(e.target.value)} placeholder="sk-ant-..." type={showKeys ? "text" : "password"} />
        </Field>
      </Section>
      <label style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, cursor: "pointer" }}>
        <input type="checkbox" checked={showKeys} onChange={(e) => setShowKeys(e.target.checked)} style={{ width: 16, height: 16 }} />
        <span style={{ fontSize: 12.5, color: T.inkSoft }}>Show values</span>
      </label>
      <PrimaryButton onClick={save} full>Save Settings</PrimaryButton>
    </ModalShell>
  );
}
