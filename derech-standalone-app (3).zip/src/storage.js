import { get as idbGet, set as idbSet } from "idb-keyval";
import { createClient } from "@supabase/supabase-js";

const LOCAL_KEY = "derech-app-data";
const CONFIG_KEY = "derech-config"; // { supabaseUrl, supabaseAnonKey, anthropicApiKey, deviceId }

// --- Config (Supabase URL/key, optional Anthropic key) lives in localStorage ---
// This is a real standalone app now (not a Claude artifact), so plain localStorage is fine.
export function getConfig() {
  try {
    return JSON.parse(localStorage.getItem(CONFIG_KEY)) || {};
  } catch {
    return {};
  }
}

export function setConfig(partial) {
  const current = getConfig();
  const next = { ...current, ...partial };
  if (!next.deviceId) next.deviceId = crypto.randomUUID();
  localStorage.setItem(CONFIG_KEY, JSON.stringify(next));
  return next;
}

function getSupabaseClient() {
  const cfg = getConfig();
  if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) return null;
  return createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
}

// --- Local (always available, instant, works fully offline) ---
export async function loadLocal() {
  const raw = await idbGet(LOCAL_KEY);
  return raw || null; // { data, updatedAt } | null
}

export async function saveLocal(data) {
  const record = { data, updatedAt: Date.now() };
  await idbSet(LOCAL_KEY, record);
  return record;
}

// --- Remote (Supabase) — used opportunistically when online ---
export async function pullRemote() {
  const client = getSupabaseClient();
  if (!client) return null;
  const { data, error } = await client
    .from("derech_data")
    .select("data, updated_at")
    .eq("id", "main")
    .maybeSingle();
  if (error || !data) return null;
  return { data: data.data, updatedAt: new Date(data.updated_at).getTime() };
}

export async function pushRemote(data) {
  const client = getSupabaseClient();
  if (!client) throw new Error("Supabase not configured");
  const { error } = await client
    .from("derech_data")
    .upsert({ id: "main", data, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export function isConfigured() {
  const cfg = getConfig();
  return Boolean(cfg.supabaseUrl && cfg.supabaseAnonKey);
}
